# Legacy PySide6 Code

> **Status**: 📦 Archived (Reference Only)  
> **Framework**: PySide6

---

## ⚠️ DO NOT USE IN PRODUCTION

These files are kept for **reference only**. The active implementation uses CustomTkinter.

---

## 📁 Files

| File | Description |
|------|-------------|
| `license_manager_gui_pyside6.py` | Original PySide6 admin GUI (56KB) |

---

## 🔗 Active Code

Use CustomTkinter version instead: `../ctk_gui/license_manager_gui.py`
