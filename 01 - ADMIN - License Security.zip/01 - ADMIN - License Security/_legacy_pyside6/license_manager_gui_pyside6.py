"""
VEO License Manager GUI
PySide6-based tool for managing license keys on Firebase

Requirements:
    pip install PySide6 firebase-admin

Usage:
    python license_manager_gui.py
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTableWidget, QTableWidgetItem, QPushButton, QLabel, QLineEdit,
    QComboBox, QSpinBox, QTextEdit, QDialog, QDialogButtonBox,
    QFormLayout, QGroupBox, QMessageBox, QStatusBar, QHeaderView,
    QSplitter, QFrame, QDateEdit
)
from PySide6.QtCore import Qt, QThread, Signal, QDate
from PySide6.QtGui import QFont, QColor, QKeySequence, QShortcut

# Import our license modules
from license_keygen import LicenseKeyGenerator, LicenseTier

# Firebase
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False


# ============================================================
# DARK THEME STYLESHEET
# ============================================================

DARK_STYLESHEET = """
QMainWindow, QDialog {
    background-color: #1e1e2e;
    color: #cdd6f4;
}

QLabel {
    color: #cdd6f4;
}

QTableWidget {
    background-color: #2d2d3d;
    color: #cdd6f4;
    gridline-color: #45475a;
    selection-background-color: #6c7086;
    border: 1px solid #45475a;
    border-radius: 4px;
}

QTableWidget::item {
    padding: 8px;
}

QTableWidget::item:selected {
    background-color: #6c7086;
}

QHeaderView::section {
    background-color: #313244;
    color: #89b4fa;
    padding: 8px;
    border: 1px solid #45475a;
    font-weight: bold;
}

QPushButton {
    background-color: #89b4fa;
    color: #1e1e2e;
    border: none;
    border-radius: 4px;
    padding: 8px 16px;
    font-weight: bold;
}

QPushButton:hover {
    background-color: #b4befe;
}

QPushButton:pressed {
    background-color: #74c7ec;
}

QPushButton:disabled {
    background-color: #45475a;
    color: #6c7086;
}

QPushButton#dangerBtn {
    background-color: #f38ba8;
}

QPushButton#dangerBtn:hover {
    background-color: #eba0ac;
}

QLineEdit, QTextEdit, QComboBox, QSpinBox, QDateEdit {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 4px;
    padding: 8px;
}

QLineEdit:focus, QTextEdit:focus, QComboBox:focus {
    border-color: #89b4fa;
}

QGroupBox {
    border: 1px solid #45475a;
    border-radius: 4px;
    margin-top: 12px;
    padding-top: 12px;
    color: #89b4fa;
    font-weight: bold;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}

QStatusBar {
    background-color: #313244;
    color: #a6adc8;
}

QComboBox::drop-down {
    border: none;
    width: 20px;
}

QComboBox QAbstractItemView {
    background-color: #313244;
    color: #cdd6f4;
    selection-background-color: #6c7086;
}

QScrollBar:vertical {
    background-color: #2d2d3d;
    width: 12px;
    border-radius: 6px;
}

QScrollBar::handle:vertical {
    background-color: #45475a;
    border-radius: 6px;
    min-height: 20px;
}

QScrollBar::handle:vertical:hover {
    background-color: #6c7086;
}
"""


# ============================================================
# FIREBASE MANAGER
# ============================================================

class FirebaseManager:
    """Manages Firebase Firestore connection and operations"""
    
    COLLECTION = "_lic"
    
    def __init__(self):
        self.db = None
        self.connected = False
    
    def find_credentials(self) -> Optional[Path]:
        """Find Firebase credentials file"""
        search_paths = [
            os.environ.get('VEO_LICENSE_CONFIG'),
            os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'),
            Path(__file__).parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
            Path(__file__).parent / "00_ADMIN" / "firebase-credentials.json",
            Path(__file__).parent.parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
            Path(__file__).parent.parent / "00_ADMIN" / "firebase-credentials.json",
            Path.home() / ".veoauto" / "firebase-credentials.json",
        ]
        
        for path in search_paths:
            if path and Path(path).exists():
                return Path(path)
        return None
    
    def connect(self) -> bool:
        """Connect to Firebase"""
        if not FIREBASE_AVAILABLE:
            return False
        
        cred_path = self.find_credentials()
        if not cred_path:
            return False
        
        try:
            if not firebase_admin._apps:
                cred = credentials.Certificate(str(cred_path))
                firebase_admin.initialize_app(cred)
            
            self.db = firestore.client()
            self.connected = True
            return True
        except Exception as e:
            print(f"Firebase error: {e}")
            return False
    
    def get_all_keys(self) -> list:
        """Get all license keys"""
        if not self.connected:
            return []
        
        docs = self.db.collection(self.COLLECTION).stream()
        keys = []
        
        for doc in docs:
            data = doc.to_dict()
            data['id'] = doc.id
            keys.append(data)
        
        return keys
    
    def create_key(self, machine_id: str, tier: LicenseTier, days: int, 
                   email: str = None, note: str = None, client_name: str = None) -> str:
        """Create a new license key"""
        key, metadata = LicenseKeyGenerator.generate(machine_id, tier, days)
        
        doc_data = {
            "_t": metadata['tier'],
            "_st": "a",
            "_cr": firestore.SERVER_TIMESTAMP,
            "_exp": datetime.fromisoformat(metadata['expires']),
            "_mid": metadata['machine_id'],
            "_em": email,
            "_nt": note,
            "_dur": days,
            "_cn": client_name,  # Client name for easier management
        }
        
        self.db.collection(self.COLLECTION).document(key).set(doc_data)
        return key
    
    def revoke_key(self, key_id: str, reason: str = "admin") -> bool:
        """Revoke a license key"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.COLLECTION).document(key_id).update({
                "_st": "r",
                "_rv_at": firestore.SERVER_TIMESTAMP,
                "_rv_reason": reason
            })
            return True
        except:
            return False
    
    def delete_key(self, key_id: str) -> bool:
        """Delete a license key permanently"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.COLLECTION).document(key_id).delete()
            return True
        except:
            return False
    
    def update_key(self, key_id: str, updates: dict) -> bool:
        """Update key fields"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.COLLECTION).document(key_id).update(updates)
            return True
        except:
            return False
    
    def get_summary(self) -> dict:
        """Get keys summary by status"""
        keys = self.get_all_keys()
        summary = {"active": 0, "revoked": 0, "expired": 0, "total": len(keys)}
        
        now = datetime.now()
        for key in keys:
            status = key.get('_st', '')
            exp = key.get('_exp')
            
            if status == 'r':
                summary['revoked'] += 1
            elif exp and hasattr(exp, 'timestamp') and datetime.fromtimestamp(exp.timestamp()) < now:
                summary['expired'] += 1
            elif status == 'a':
                summary['active'] += 1
        
        return summary
    
    def cleanup_expired_keys(self) -> int:
        """
        Mark all expired keys as 'e' (expired).
        Returns number of keys marked.
        """
        if not self.connected:
            return 0
        
        now = datetime.now()
        count = 0
        
        # Query active keys that have expired
        try:
            expired_docs = self.db.collection(self.COLLECTION) \
                .where("_st", "==", "a") \
                .where("_exp", "<", now) \
                .stream()
            
            for doc in expired_docs:
                doc.reference.update({
                    "_st": "e",  # expired
                    "_expired_at": firestore.SERVER_TIMESTAMP
                })
                count += 1
        except Exception as e:
            print(f"Cleanup error: {e}")
        
        return count
    
    def delete_expired_keys(self, include_revoked: bool = False, backup_dir: str = None) -> tuple:
        """
        Permanently DELETE all expired keys (and optionally revoked).
        Creates backup report BEFORE deletion.
        
        Args:
            include_revoked: Also delete revoked keys
            backup_dir: Directory to save backup reports (default: ~/.veoauto/backups/)
            
        Returns:
            (deleted_count, backup_path)
        """
        if not self.connected:
            return 0, None
        
        # Default backup directory
        if backup_dir is None:
            backup_dir = Path.home() / ".veoauto" / "backups"
        else:
            backup_dir = Path(backup_dir)
        
        now = datetime.now()
        
        # Create date-organized folder: backups/2026/02/02/
        date_folder = backup_dir / now.strftime("%Y") / now.strftime("%m") / now.strftime("%d")
        date_folder.mkdir(parents=True, exist_ok=True)
        
        # Collect keys to delete with full data
        keys_to_delete = []
        
        try:
            all_docs = self.db.collection(self.COLLECTION).stream()
            
            for doc in all_docs:
                data = doc.to_dict()
                status = data.get('_st', '')
                exp = data.get('_exp')
                
                should_delete = False
                delete_reason = ""
                
                # Check expired status
                if status == 'e':
                    should_delete = True
                    delete_reason = "expired_status"
                
                # Check actually expired (but not marked)
                if exp and hasattr(exp, 'timestamp'):
                    if datetime.fromtimestamp(exp.timestamp()) < now:
                        should_delete = True
                        delete_reason = "expired_date"
                
                # Include revoked if requested
                if include_revoked and status == 'r':
                    should_delete = True
                    delete_reason = "revoked"
                
                if should_delete:
                    # Convert Firestore types to JSON-serializable
                    record = {
                        "key_id": doc.id,
                        "delete_reason": delete_reason,
                        "deleted_at": now.isoformat(),
                        "original_data": {}
                    }
                    
                    # Safely convert all fields
                    for k, v in data.items():
                        if hasattr(v, 'isoformat'):  # datetime
                            record["original_data"][k] = v.isoformat()
                        elif hasattr(v, 'timestamp'):  # Firestore Timestamp
                            record["original_data"][k] = datetime.fromtimestamp(v.timestamp()).isoformat()
                        else:
                            record["original_data"][k] = v
                    
                    # VND Pricing tier mapping
                    tier_map = {
                        "TRIA": "Trial (7d)", "1M": "1 Tháng", "3M": "3 Tháng",
                        "6M": "6 Tháng", "1Y": "1 Năm", "LT": "Vĩnh viễn"
                    }
                    record["tier_name"] = tier_map.get(data.get('_t', ''), data.get('_t', ''))
                    
                    keys_to_delete.append((doc, record))
                    
        except Exception as e:
            print(f"Collect keys error: {e}")
            return 0, None
        
        if not keys_to_delete:
            return 0, None
        
        # Create backup report
        backup_filename = now.strftime("deleted_keys_%Y%m%d_%H%M%S.json")
        backup_path = date_folder / backup_filename
        
        # Build full report
        report = {
            "report_info": {
                "generated_at": now.isoformat(),
                "total_deleted": len(keys_to_delete),
                "include_revoked": include_revoked,
                "backup_format_version": "1.0"
            },
            "summary": {
                "expired": sum(1 for _, r in keys_to_delete if r["delete_reason"] in ["expired_status", "expired_date"]),
                "revoked": sum(1 for _, r in keys_to_delete if r["delete_reason"] == "revoked")
            },
            "deleted_keys": [record for _, record in keys_to_delete]
        }
        
        # Save backup BEFORE deleting
        try:
            import json
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            print(f"✅ Backup saved: {backup_path}")
        except Exception as e:
            print(f"❌ Backup failed: {e}")
            return 0, None  # Don't delete if backup fails!
        
        # Now delete from Firebase
        count = 0
        for doc, _ in keys_to_delete:
            try:
                doc.reference.delete()
                count += 1
            except Exception as e:
                print(f"Delete error for {doc.id}: {e}")
        
        return count, str(backup_path)
    
    # =========================================================================
    # LICENSE REQUEST HANDLING
    # =========================================================================
    
    REQUEST_COLLECTION = "_license_requests"
    
    def get_pending_requests(self) -> list:
        """Get all pending license requests"""
        if not self.connected:
            return []
        
        try:
            docs = self.db.collection(self.REQUEST_COLLECTION) \
                .where("status", "==", "pending") \
                .order_by("created_at", direction=firestore.Query.DESCENDING) \
                .stream()
            
            requests = []
            for doc in docs:
                data = doc.to_dict()
                data['id'] = doc.id
                requests.append(data)
            
            return requests
        except Exception as e:
            print(f"Get requests error: {e}")
            return []
    
    def get_all_requests(self) -> list:
        """Get all license requests (all statuses)"""
        if not self.connected:
            return []
        
        try:
            docs = self.db.collection(self.REQUEST_COLLECTION).stream()
            requests = []
            for doc in docs:
                data = doc.to_dict()
                data['id'] = doc.id
                requests.append(data)
            return requests
        except:
            return []
    
    def approve_request(self, request_id: str, tier: LicenseTier, days: int, 
                        admin_email: str = "admin") -> tuple:
        """
        Approve a license request and generate key.
        
        Returns:
            (success: bool, license_key: str or error_message: str)
        """
        if not self.connected:
            return False, "Not connected"
        
        try:
            doc_ref = self.db.collection(self.REQUEST_COLLECTION).document(request_id)
            doc = doc_ref.get()
            
            if not doc.exists:
                return False, "Request not found"
            
            data = doc.to_dict()
            machine_id = data.get('machine_id')
            
            if not machine_id:
                return False, "Invalid request: no machine_id"
            
            # Generate license key
            key, metadata = LicenseKeyGenerator.generate(machine_id, tier, days)
            
            # Create license in _lic collection
            lic_data = {
                "_t": metadata['tier'],
                "_st": "a",  # active
                "_cr": firestore.SERVER_TIMESTAMP,
                "_exp": datetime.fromisoformat(metadata['expires']),
                "_mid": machine_id,
                "_em": data.get('email'),
                "_cn": data.get('client_name'),
                "_nt": f"Auto-generated from request {request_id}",
                "_dur": days,
            }
            self.db.collection(self.COLLECTION).document(key).set(lic_data)
            
            # Update request status
            doc_ref.update({
                "status": "approved",
                "approved_key": key,
                "processed_at": firestore.SERVER_TIMESTAMP,
                "processed_by": admin_email,
                "admin_note": f"Approved: {tier.name} for {days} days"
            })
            
            return True, key
            
        except Exception as e:
            return False, str(e)
    
    def reject_request(self, request_id: str, reason: str, admin_email: str = "admin") -> bool:
        """Reject a license request"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.REQUEST_COLLECTION).document(request_id).update({
                "status": "rejected",
                "admin_note": reason,
                "processed_at": firestore.SERVER_TIMESTAMP,
                "processed_by": admin_email
            })
            return True
        except:
            return False
    
    def get_request_summary(self) -> dict:
        """Get summary of requests by status"""
        requests = self.get_all_requests()
        summary = {"pending": 0, "approved": 0, "rejected": 0, "total": len(requests)}
        
        for req in requests:
            status = req.get('status', 'pending')
            if status in summary:
                summary[status] += 1
        
        return summary


# ============================================================
# CREATE KEY DIALOG
# ============================================================

class CreateKeyDialog(QDialog):
    """Dialog for creating new license key"""
    
    def __init__(self, firebase: FirebaseManager, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.created_key = None
        self.setup_ui()
    
    def setup_ui(self):
        self.setWindowTitle("➕ Create New License Key")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        
        form = QFormLayout()
        
        # Machine ID (required)
        self.machine_id_input = QLineEdit()
        self.machine_id_input.setPlaceholderText("e.g., 3946C15B")
        form.addRow("Machine ID *:", self.machine_id_input)
        
        # Client Name (for management)
        self.client_name_input = QLineEdit()
        self.client_name_input.setPlaceholderText("e.g., Nguyễn Văn A")
        form.addRow("Client Name:", self.client_name_input)
        
        # VND Pricing tiers
        self.tier_combo = QComboBox()
        self.tier_combo.addItems([
            "Trial (7d) - Miễn phí",
            "1 Tháng - 300,000đ",
            "3 Tháng - 500,000đ",
            "6 Tháng - 800,000đ",
            "1 Năm - 1,200,000đ",
            "Vĩnh viễn - 3,000,000đ"
        ])
        self.tier_combo.setCurrentText("1 Tháng - 300,000đ")
        form.addRow("Tier:", self.tier_combo)
        
        # Duration
        self.days_spin = QSpinBox()
        self.days_spin.setRange(7, 3650)
        self.days_spin.setValue(30)
        self.days_spin.setSuffix(" days")
        form.addRow("Duration:", self.days_spin)
        
        # Email (optional)
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("customer@example.com")
        form.addRow("Email:", self.email_input)
        
        # Note (optional)
        self.note_input = QTextEdit()
        self.note_input.setMaximumHeight(80)
        self.note_input.setPlaceholderText("Admin notes...")
        form.addRow("Note:", self.note_input)
        
        layout.addLayout(form)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.create_key)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def create_key(self):
        machine_id = self.machine_id_input.text().strip()
        
        if len(machine_id) < 4:
            QMessageBox.warning(self, "Error", "Machine ID must be at least 4 characters!")
            return
        
        tier = LicenseTier.from_name(self.tier_combo.currentText())
        days = self.days_spin.value()
        email = self.email_input.text().strip() or None
        note = self.note_input.toPlainText().strip() or None
        client_name = self.client_name_input.text().strip() or None
        
        try:
            self.created_key = self.firebase.create_key(machine_id, tier, days, email, note, client_name)
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create key: {e}")


# ============================================================
# EDIT KEY DIALOG
# ============================================================

class EditKeyDialog(QDialog):
    """Dialog for editing existing license key"""
    
    def __init__(self, firebase: FirebaseManager, key_id: str, key_data: dict, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.key_id = key_id
        self.key_data = key_data
        self.original_expiry = None
        self.setup_ui()
    
    def setup_ui(self):
        self.setWindowTitle(f"✏️ Edit Key: {self.key_id[:25]}...")
        self.setMinimumWidth(450)
        
        layout = QVBoxLayout(self)
        
        # === KEY INFORMATION (readonly) ===
        info_group = QGroupBox("Key Information")
        info_layout = QFormLayout()
        
        key_label = QLineEdit(self.key_id)
        key_label.setReadOnly(True)
        info_layout.addRow("Key:", key_label)
        
        mid_label = QLineEdit(self.key_data.get('_mid', 'N/A'))
        mid_label.setReadOnly(True)
        info_layout.addRow("Machine ID:", mid_label)
        
        # VND Pricing tier mapping
        tier_map = {
            "TRIA": "Trial (7d)", "1M": "1 Tháng", "3M": "3 Tháng",
            "6M": "6 Tháng", "1Y": "1 Năm", "LT": "Vĩnh viễn"
        }
        tier_label = QLineEdit(tier_map.get(self.key_data.get('_t', ''), self.key_data.get('_t', '')))
        tier_label.setReadOnly(True)
        info_layout.addRow("Tier:", tier_label)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # === LICENSE STATUS (editable) ===
        status_group = QGroupBox("License Status")
        status_layout = QFormLayout()
        
        # Status
        self.status_combo = QComboBox()
        self.status_combo.addItems(["✅ Active", "⏸️ Suspended", "❌ Revoked"])
        current_status = self.key_data.get('_st', 'a')
        status_map = {'a': 0, 's': 1, 'r': 2}
        self.status_combo.setCurrentIndex(status_map.get(current_status, 0))
        status_layout.addRow("Status:", self.status_combo)
        
        # Expiry date with warning
        self.expiry_date = QDateEdit()
        self.expiry_date.setCalendarPopup(True)
        exp = self.key_data.get('_exp')
        if exp and hasattr(exp, 'year'):
            self.original_expiry = QDate(exp.year, exp.month, exp.day)
            self.expiry_date.setDate(self.original_expiry)
        else:
            self.original_expiry = QDate.currentDate().addDays(30)
            self.expiry_date.setDate(self.original_expiry)
        status_layout.addRow("Expires:", self.expiry_date)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        # === CUSTOMER INFO (editable) ===
        customer_group = QGroupBox("Customer Info")
        customer_layout = QFormLayout()
        
        # Client Name
        self.client_name_input = QLineEdit()
        self.client_name_input.setText(self.key_data.get('_cn', '') or '')
        self.client_name_input.setPlaceholderText("e.g., Nguyễn Văn A")
        customer_layout.addRow("Name:", self.client_name_input)
        
        # Email
        self.email_input = QLineEdit()
        self.email_input.setText(self.key_data.get('_em', '') or '')
        self.email_input.setPlaceholderText("customer@example.com")
        customer_layout.addRow("Email:", self.email_input)
        
        # Note
        self.note_input = QTextEdit()
        self.note_input.setMaximumHeight(60)
        self.note_input.setText(self.key_data.get('_nt', '') or '')
        self.note_input.setPlaceholderText("Admin notes...")
        customer_layout.addRow("Note:", self.note_input)
        
        customer_group.setLayout(customer_layout)
        layout.addWidget(customer_group)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.save_changes)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def save_changes(self):
        status_map = {0: 'a', 1: 's', 2: 'r'}
        new_status = status_map[self.status_combo.currentIndex()]
        
        qdate = self.expiry_date.date()
        new_expiry = datetime(qdate.year(), qdate.month(), qdate.day())
        
        # Check if expiry is being extended → show warning
        if qdate > self.original_expiry:
            days_added = self.original_expiry.daysTo(qdate)
            reply = QMessageBox.warning(
                self, "⚠️ Gia hạn License",
                f"Bạn đang GIA HẠN license thêm {days_added} ngày!\n\n"
                f"Ngày hết hạn cũ: {self.original_expiry.toString('yyyy-MM-dd')}\n"
                f"Ngày hết hạn mới: {qdate.toString('yyyy-MM-dd')}\n\n"
                f"Xác nhận gia hạn?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        new_note = self.note_input.toPlainText().strip() or None
        new_email = self.email_input.text().strip() or None
        new_client_name = self.client_name_input.text().strip() or None
        
        updates = {
            '_st': new_status,
            '_exp': new_expiry,
            '_nt': new_note,
            '_em': new_email,
            '_cn': new_client_name,
        }
        
        if self.firebase.update_key(self.key_id, updates):
            self.accept()
        else:
            QMessageBox.critical(self, "Error", "Failed to save changes!")


# ============================================================
# MAIN WINDOW
# ============================================================

class LicenseManagerWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.firebase = FirebaseManager()
        self.keys_data = []
        self.setup_ui()
        self.connect_firebase()
        self.refresh_keys()
        self.update_requests_badge()  # Show pending requests count on startup
    
    def setup_ui(self):
        self.setWindowTitle("🔐 VEO License Manager")
        self.setMinimumSize(900, 600)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(12)
        layout.setContentsMargins(12, 12, 12, 12)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_keys)
        toolbar.addWidget(refresh_btn)
        
        create_btn = QPushButton("➕ Create Key")
        create_btn.clicked.connect(self.create_key_dialog)
        toolbar.addWidget(create_btn)
        
        revoke_btn = QPushButton("🗑️ Revoke")
        revoke_btn.setObjectName("dangerBtn")
        revoke_btn.clicked.connect(self.revoke_selected_key)
        toolbar.addWidget(revoke_btn)
        
        delete_btn = QPushButton("❌ Delete")
        delete_btn.setObjectName("dangerBtn")
        delete_btn.clicked.connect(self.delete_selected_key)
        toolbar.addWidget(delete_btn)
        
        # Separator
        separator1 = QWidget()
        separator1.setFixedWidth(20)
        toolbar.addWidget(separator1)
        
        # Cleanup expired button
        cleanup_btn = QPushButton("🧹 Cleanup Expired")
        cleanup_btn.setToolTip("Mark all expired keys and optionally delete them")
        cleanup_btn.clicked.connect(self.cleanup_expired_dialog)
        toolbar.addWidget(cleanup_btn)
        
        toolbar.addStretch()
        
        # Pending requests button with badge
        self.requests_btn = QPushButton("📬 Requests")
        self.requests_btn.setToolTip("View pending license requests")
        self.requests_btn.clicked.connect(self.show_requests_dialog)
        toolbar.addWidget(self.requests_btn)
        
        summary_btn = QPushButton("📊 Summary")
        summary_btn.clicked.connect(self.show_summary)
        toolbar.addWidget(summary_btn)
        
        layout.addLayout(toolbar)
        
        # Splitter for table + details
        splitter = QSplitter(Qt.Horizontal)
        
        # Table - Client first, then Key (full display)
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Client", "Key", "Machine ID", "Tier", "Status", "Expires"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)  # Key column stretches
        self.table.itemSelectionChanged.connect(self.on_key_selected)
        splitter.addWidget(self.table)
        
        # Details panel - organized like Edit dialog
        details_widget = QWidget()
        details_layout = QVBoxLayout(details_widget)
        
        # === KEY INFORMATION ===
        key_info_group = QGroupBox("Key Information")
        key_info_form = QFormLayout()
        
        self.detail_key = QLineEdit()
        self.detail_key.setReadOnly(True)
        key_info_form.addRow("Key:", self.detail_key)
        
        self.detail_mid = QLineEdit()
        self.detail_mid.setReadOnly(True)
        key_info_form.addRow("Machine ID:", self.detail_mid)
        
        self.detail_tier = QLineEdit()
        self.detail_tier.setReadOnly(True)
        key_info_form.addRow("Tier:", self.detail_tier)
        
        key_info_group.setLayout(key_info_form)
        details_layout.addWidget(key_info_group)
        
        # === LICENSE STATUS ===
        status_group = QGroupBox("License Status")
        status_form = QFormLayout()
        
        self.detail_status = QLineEdit()
        self.detail_status.setReadOnly(True)
        status_form.addRow("Status:", self.detail_status)
        
        self.detail_created = QLineEdit()
        self.detail_created.setReadOnly(True)
        status_form.addRow("Created:", self.detail_created)
        
        self.detail_expires = QLineEdit()
        self.detail_expires.setReadOnly(True)
        status_form.addRow("Expires:", self.detail_expires)
        
        status_group.setLayout(status_form)
        details_layout.addWidget(status_group)
        
        # === CUSTOMER INFO ===
        customer_group = QGroupBox("Customer Info")
        customer_form = QFormLayout()
        
        self.detail_client = QLineEdit()
        self.detail_client.setReadOnly(True)
        customer_form.addRow("Name:", self.detail_client)
        
        self.detail_email = QLineEdit()
        self.detail_email.setReadOnly(True)
        customer_form.addRow("Email:", self.detail_email)
        
        self.detail_note = QTextEdit()
        self.detail_note.setReadOnly(True)
        self.detail_note.setMaximumHeight(50)
        customer_form.addRow("Note:", self.detail_note)
        
        customer_group.setLayout(customer_form)
        details_layout.addWidget(customer_group)
        
        # Detail buttons
        detail_buttons = QHBoxLayout()
        
        copy_btn = QPushButton("📋 Copy Key")
        copy_btn.clicked.connect(self.copy_key_to_clipboard)
        detail_buttons.addWidget(copy_btn)
        
        edit_btn = QPushButton("✏️ Edit")
        edit_btn.clicked.connect(self.edit_key_dialog)
        detail_buttons.addWidget(edit_btn)
        
        details_layout.addLayout(detail_buttons)
        details_layout.addStretch()
        
        splitter.addWidget(details_widget)
        splitter.setSizes([600, 300])
        
        layout.addWidget(splitter)
        
        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Starting...")
        
        # Keyboard shortcuts
        QShortcut(QKeySequence("Ctrl+N"), self, self.create_key_dialog)
        QShortcut(QKeySequence("F5"), self, self.refresh_keys)
        QShortcut(QKeySequence("Delete"), self, self.revoke_selected_key)
    
    def connect_firebase(self):
        if self.firebase.connect():
            self.status_bar.showMessage("✅ Connected to Firebase")
        else:
            self.status_bar.showMessage("❌ Firebase connection failed!")
            QMessageBox.warning(self, "Warning", 
                "Could not connect to Firebase.\nMake sure credentials file exists.")
    
    def refresh_keys(self):
        self.keys_data = self.firebase.get_all_keys()
        self.table.setRowCount(len(self.keys_data))
        
        for i, key_data in enumerate(self.keys_data):
            key_id = key_data.get('id', '')
            client = key_data.get('_cn', '') or ''
            mid = key_data.get('_mid', '')[:8] if key_data.get('_mid') else ''
            tier = key_data.get('_t', '')
            status = key_data.get('_st', '')
            exp = key_data.get('_exp')
            
            status_display = {"a": "✅", "r": "❌", "e": "⏰", "s": "⏸️"}.get(status, status)
            exp_display = exp.strftime('%Y-%m-%d') if hasattr(exp, 'strftime') else str(exp)[:10] if exp else ''
            
            # Column order: Client, Key (full), MID, Tier, Status, Expires
            self.table.setItem(i, 0, QTableWidgetItem(client))
            self.table.setItem(i, 1, QTableWidgetItem(key_id))  # Full key, no truncation
            self.table.setItem(i, 2, QTableWidgetItem(mid))
            self.table.setItem(i, 3, QTableWidgetItem(tier))
            self.table.setItem(i, 4, QTableWidgetItem(status_display))
            self.table.setItem(i, 5, QTableWidgetItem(exp_display))
        
        summary = self.firebase.get_summary()
        self.status_bar.showMessage(
            f"✅ Connected | Total: {summary['total']} | Active: {summary['active']} | Revoked: {summary['revoked']} | Expired: {summary['expired']}"
        )
    
    def on_key_selected(self):
        rows = self.table.selectedIndexes()
        if not rows:
            return
        
        row = rows[0].row()
        if row < len(self.keys_data):
            data = self.keys_data[row]
            
            self.detail_key.setText(data.get('id', ''))
            self.detail_client.setText(data.get('_cn', '') or '')
            self.detail_mid.setText(data.get('_mid', ''))
            
            # VND Pricing tier mapping
            tier_map = {
                "TRIA": "Trial (7d)", "1M": "1 Tháng", "3M": "3 Tháng",
                "6M": "6 Tháng", "1Y": "1 Năm", "LT": "Vĩnh viễn"
            }
            self.detail_tier.setText(tier_map.get(data.get('_t', ''), data.get('_t', '')))
            
            status_map = {"a": "Active", "r": "Revoked", "e": "Expired", "s": "Suspended"}
            self.detail_status.setText(status_map.get(data.get('_st', ''), data.get('_st', '')))
            
            cr = data.get('_cr')
            self.detail_created.setText(cr.strftime('%Y-%m-%d %H:%M') if hasattr(cr, 'strftime') else str(cr)[:16] if cr else '')
            
            exp = data.get('_exp')
            self.detail_expires.setText(exp.strftime('%Y-%m-%d') if hasattr(exp, 'strftime') else str(exp)[:10] if exp else '')
            
            self.detail_email.setText(data.get('_em', '') or '')
            self.detail_note.setText(data.get('_nt', '') or '')
    
    def create_key_dialog(self):
        dialog = CreateKeyDialog(self.firebase, self)
        if dialog.exec() == QDialog.Accepted and dialog.created_key:
            QMessageBox.information(self, "Success", 
                f"Key created:\n\n{dialog.created_key}\n\nCopied to clipboard!")
            QApplication.clipboard().setText(dialog.created_key)
            self.refresh_keys()
    
    def edit_key_dialog(self):
        key_id = self.detail_key.text()
        if not key_id:
            QMessageBox.warning(self, "Warning", "Please select a key first!")
            return
        
        # Find key data
        key_data = None
        for data in self.keys_data:
            if data.get('id') == key_id:
                key_data = data
                break
        
        if not key_data:
            return
        
        dialog = EditKeyDialog(self.firebase, key_id, key_data, self)
        if dialog.exec() == QDialog.Accepted:
            self.refresh_keys()
    
    def revoke_selected_key(self):
        key_id = self.detail_key.text()
        if not key_id:
            QMessageBox.warning(self, "Warning", "Please select a key first!")
            return
        
        reply = QMessageBox.question(
            self, "Confirm Revoke",
            f"Are you sure you want to revoke this key?\n\n{key_id[:40]}...",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.revoke_key(key_id, "admin"):
                QMessageBox.information(self, "Success", "Key revoked!")
                self.refresh_keys()
            else:
                QMessageBox.critical(self, "Error", "Failed to revoke key!")
    
    def delete_selected_key(self):
        key_id = self.detail_key.text()
        if not key_id:
            QMessageBox.warning(self, "Warning", "Please select a key first!")
            return
        
        reply = QMessageBox.warning(
            self, "⚠️ Confirm DELETE",
            f"Are you sure you want to PERMANENTLY DELETE this key?\n\n{key_id[:40]}...\n\nThis action cannot be undone!",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.delete_key(key_id):
                QMessageBox.information(self, "Success", "Key deleted!")
                self.refresh_keys()
            else:
                QMessageBox.critical(self, "Error", "Failed to delete key!")
    
    def copy_key_to_clipboard(self):
        key_id = self.detail_key.text()
        if key_id:
            QApplication.clipboard().setText(key_id)
            self.status_bar.showMessage("📋 Key copied to clipboard!", 3000)
    
    def show_summary(self):
        summary = self.firebase.get_summary()
        QMessageBox.information(
            self, "📊 License Summary",
            f"Total Keys: {summary['total']}\n\n"
            f"✅ Active: {summary['active']}\n"
            f"❌ Revoked: {summary['revoked']}\n"
            f"⏰ Expired: {summary['expired']}"
        )
    
    def cleanup_expired_dialog(self):
        """Show cleanup options dialog"""
        summary = self.firebase.get_summary()
        
        msg = QMessageBox(self)
        msg.setWindowTitle("🧹 Cleanup Expired Keys")
        msg.setText(
            f"<b>Current Status:</b><br>"
            f"⏰ Expired: {summary['expired']}<br>"
            f"❌ Revoked: {summary['revoked']}<br><br>"
            f"<b>What would you like to do?</b>"
        )
        msg.setIcon(QMessageBox.Question)
        
        # Custom buttons
        mark_btn = msg.addButton("Mark Expired Only", QMessageBox.ActionRole)
        delete_expired_btn = msg.addButton("Delete Expired", QMessageBox.DestructiveRole)
        delete_all_btn = msg.addButton("Delete Expired + Revoked", QMessageBox.DestructiveRole)
        cancel_btn = msg.addButton("Cancel", QMessageBox.RejectRole)
        
        msg.exec()
        clicked = msg.clickedButton()
        
        if clicked == mark_btn:
            # Mark expired keys
            count = self.firebase.cleanup_expired_keys()
            QMessageBox.information(
                self, "✅ Cleanup Complete",
                f"Marked {count} expired keys.\n\nStatus changed from 'Active' to 'Expired'."
            )
            self.refresh_keys()
            
        elif clicked == delete_expired_btn:
            # Confirm delete expired
            reply = QMessageBox.warning(
                self, "⚠️ Confirm Delete Expired",
                f"This will PERMANENTLY DELETE all expired keys!\n\n"
                f"Estimated: {summary['expired']} keys\n\n"
                f"This action cannot be undone. Continue?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                count, backup_path = self.firebase.delete_expired_keys(include_revoked=False)
                if backup_path:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"Permanently deleted {count} expired keys.\n\n"
                        f"📁 Backup saved to:\n{backup_path}"
                    )
                else:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"No expired keys to delete (or backup failed)."
                    )
                self.refresh_keys()
                
        elif clicked == delete_all_btn:
            # Confirm delete expired + revoked
            total = summary['expired'] + summary['revoked']
            reply = QMessageBox.warning(
                self, "⚠️ Confirm Delete All",
                f"This will PERMANENTLY DELETE:\n\n"
                f"⏰ Expired keys: {summary['expired']}\n"
                f"❌ Revoked keys: {summary['revoked']}\n"
                f"───────────────\n"
                f"Total: {total} keys\n\n"
                f"A backup report will be saved before deletion.\n"
                f"Continue?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                count, backup_path = self.firebase.delete_expired_keys(include_revoked=True)
                if backup_path:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"Permanently deleted {count} keys (expired + revoked).\n\n"
                        f"📁 Backup saved to:\n{backup_path}"
                    )
                    # Offer to open backup folder
                    import subprocess
                    reply2 = QMessageBox.question(
                        self, "Open Backup Folder?",
                        "Would you like to open the backup folder?",
                        QMessageBox.Yes | QMessageBox.No
                    )
                    if reply2 == QMessageBox.Yes:
                        folder = str(Path(backup_path).parent)
                        subprocess.run(['explorer', folder])
                else:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"No keys to delete (or backup failed)."
                    )
                self.refresh_keys()
    
    def show_requests_dialog(self):
        """Show pending requests dialog"""
        dialog = RequestsDialog(self.firebase, self)
        dialog.exec()
        self.update_requests_badge()
    
    def update_requests_badge(self):
        """Update requests button with pending count"""
        summary = self.firebase.get_request_summary()
        pending = summary.get('pending', 0)
        if pending > 0:
            self.requests_btn.setText(f"📬 Requests ({pending})")
            self.requests_btn.setStyleSheet("background-color: #fab387; color: #1e1e2e;")
        else:
            self.requests_btn.setText("📬 Requests")
            self.requests_btn.setStyleSheet("")


# ============================================================
# REQUESTS DIALOG
# ============================================================

class RequestsDialog(QDialog):
    """Dialog for viewing and managing license requests"""
    
    def __init__(self, firebase: FirebaseManager, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.requests_data = []
        self.setup_ui()
        self.refresh_requests()
    
    def setup_ui(self):
        self.setWindowTitle("📬 Pending License Requests")
        self.setMinimumSize(900, 600)
        
        layout = QVBoxLayout(self)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_requests)
        toolbar.addWidget(refresh_btn)
        
        toolbar.addStretch()
        
        self.status_label = QLabel()
        toolbar.addWidget(self.status_label)
        
        layout.addLayout(toolbar)
        
        # Splitter
        splitter = QSplitter(Qt.Horizontal)
        
        # Requests table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Tên", "Email", "SĐT", "Gói", "Machine ID", "Ngày gửi"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self.on_request_selected)
        splitter.addWidget(self.table)
        
        # Details panel
        details_widget = QWidget()
        details_layout = QVBoxLayout(details_widget)
        
        # Request info
        info_group = QGroupBox("Thông tin yêu cầu")
        info_form = QFormLayout()
        
        self.detail_name = QLineEdit()
        self.detail_name.setReadOnly(True)
        info_form.addRow("Họ tên:", self.detail_name)
        
        self.detail_email = QLineEdit()
        self.detail_email.setReadOnly(True)
        info_form.addRow("Email:", self.detail_email)
        
        self.detail_phone = QLineEdit()
        self.detail_phone.setReadOnly(True)
        info_form.addRow("SĐT:", self.detail_phone)
        
        self.detail_company = QLineEdit()
        self.detail_company.setReadOnly(True)
        info_form.addRow("Công ty:", self.detail_company)
        
        self.detail_address = QLineEdit()
        self.detail_address.setReadOnly(True)
        info_form.addRow("Địa chỉ:", self.detail_address)
        
        self.detail_machine = QLineEdit()
        self.detail_machine.setReadOnly(True)
        info_form.addRow("Machine ID:", self.detail_machine)
        
        self.detail_reason = QTextEdit()
        self.detail_reason.setReadOnly(True)
        self.detail_reason.setMaximumHeight(60)
        info_form.addRow("Lý do:", self.detail_reason)
        
        info_group.setLayout(info_form)
        details_layout.addWidget(info_group)
        
        # Approval section
        approval_group = QGroupBox("Phê duyệt")
        approval_form = QFormLayout()
        
        self.tier_combo = QComboBox()
        self.tier_combo.addItems(["TRIAL", "BASIC", "PRO", "ENTERPRISE"])
        approval_form.addRow("Gói:", self.tier_combo)
        
        self.days_spin = QSpinBox()
        self.days_spin.setRange(7, 3650)
        self.days_spin.setValue(30)
        self.days_spin.setSuffix(" ngày")
        approval_form.addRow("Thời hạn:", self.days_spin)
        
        self.reject_reason = QLineEdit()
        self.reject_reason.setPlaceholderText("Lý do từ chối (nếu reject)")
        approval_form.addRow("Lý do từ chối:", self.reject_reason)
        
        approval_group.setLayout(approval_form)
        details_layout.addWidget(approval_group)
        
        # Action buttons
        action_layout = QHBoxLayout()
        
        approve_btn = QPushButton("✅ APPROVE")
        approve_btn.setStyleSheet("background-color: #a6e3a1; color: #1e1e2e; font-weight: bold;")
        approve_btn.clicked.connect(self.approve_request)
        action_layout.addWidget(approve_btn)
        
        reject_btn = QPushButton("❌ REJECT")
        reject_btn.setStyleSheet("background-color: #f38ba8; color: #1e1e2e; font-weight: bold;")
        reject_btn.clicked.connect(self.reject_request)
        action_layout.addWidget(reject_btn)
        
        details_layout.addLayout(action_layout)
        details_layout.addStretch()
        
        splitter.addWidget(details_widget)
        splitter.setSizes([500, 400])
        
        layout.addWidget(splitter)
    
    def refresh_requests(self):
        """Refresh requests list"""
        self.requests_data = self.firebase.get_pending_requests()
        self.table.setRowCount(len(self.requests_data))
        
        for i, req in enumerate(self.requests_data):
            name = req.get('client_name', '')
            email = req.get('email', '')
            phone = req.get('phone', '')
            tier = req.get('requested_tier', 'TRIAL')
            mid = req.get('display_id', '')
            created = req.get('created_at')
            created_str = created.strftime('%Y-%m-%d %H:%M') if hasattr(created, 'strftime') else ''
            
            self.table.setItem(i, 0, QTableWidgetItem(name))
            self.table.setItem(i, 1, QTableWidgetItem(email))
            self.table.setItem(i, 2, QTableWidgetItem(phone))
            self.table.setItem(i, 3, QTableWidgetItem(tier))
            self.table.setItem(i, 4, QTableWidgetItem(mid))
            self.table.setItem(i, 5, QTableWidgetItem(created_str))
        
        self.status_label.setText(f"Tổng: {len(self.requests_data)} yêu cầu đang chờ")
    
    def on_request_selected(self):
        """Handle request selection"""
        rows = self.table.selectedIndexes()
        if not rows:
            return
        
        row = rows[0].row()
        if row < len(self.requests_data):
            req = self.requests_data[row]
            
            self.detail_name.setText(req.get('client_name', ''))
            self.detail_email.setText(req.get('email', ''))
            self.detail_phone.setText(req.get('phone', ''))
            self.detail_company.setText(req.get('company', ''))
            self.detail_address.setText(req.get('address', ''))
            self.detail_machine.setText(req.get('machine_id', '')[:32] + '...')
            self.detail_reason.setText(req.get('reason', ''))
            
            # Set default tier from request
            tier = req.get('requested_tier', 'TRIAL')
            idx = self.tier_combo.findText(tier)
            if idx >= 0:
                self.tier_combo.setCurrentIndex(idx)
            
            # Set default days
            self.days_spin.setValue(req.get('requested_days', 30))
    
    def get_selected_request(self):
        """Get currently selected request"""
        rows = self.table.selectedIndexes()
        if not rows:
            return None
        
        row = rows[0].row()
        if row < len(self.requests_data):
            return self.requests_data[row]
        return None
    
    def approve_request(self):
        """Approve selected request"""
        req = self.get_selected_request()
        if not req:
            QMessageBox.warning(self, "Warning", "Vui lòng chọn một yêu cầu!")
            return
        
        tier_name = self.tier_combo.currentText()
        tier = LicenseTier.from_name(tier_name)
        days = self.days_spin.value()
        
        reply = QMessageBox.question(
            self, "Xác nhận APPROVE",
            f"Duyệt yêu cầu của {req.get('client_name')}?\n\n"
            f"Gói: {tier_name}\n"
            f"Thời hạn: {days} ngày\n\n"
            f"License key sẽ được tự động tạo.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            success, result = self.firebase.approve_request(req.get('id'), tier, days)
            
            if success:
                QMessageBox.information(
                    self, "✅ Đã duyệt!",
                    f"License key đã được tạo:\n\n{result}\n\n"
                    f"Key đã được copy vào clipboard."
                )
                QApplication.clipboard().setText(result)
                self.refresh_requests()
            else:
                QMessageBox.critical(self, "Error", f"Lỗi: {result}")
    
    def reject_request(self):
        """Reject selected request"""
        req = self.get_selected_request()
        if not req:
            QMessageBox.warning(self, "Warning", "Vui lòng chọn một yêu cầu!")
            return
        
        reason = self.reject_reason.text().strip()
        if not reason:
            reason = "Yêu cầu không được duyệt"
        
        reply = QMessageBox.warning(
            self, "Xác nhận REJECT",
            f"Từ chối yêu cầu của {req.get('client_name')}?\n\n"
            f"Lý do: {reason}",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.reject_request(req.get('id'), reason):
                QMessageBox.information(self, "✅ Đã từ chối", "Yêu cầu đã bị từ chối.")
                self.refresh_requests()
            else:
                QMessageBox.critical(self, "Error", "Không thể từ chối yêu cầu!")


# ============================================================
# MAIN
# ============================================================

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(DARK_STYLESHEET)
    
    window = LicenseManagerWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
