"""
Cleanup Expired License Keys
Run daily via cron/scheduler to mark expired keys

Usage:
    python cleanup_expired_keys.py
    python cleanup_expired_keys.py --dry-run  # Preview without changes
"""

import argparse
from datetime import datetime
from pathlib import Path
import os

# Firebase Admin SDK
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False
    print("❌ firebase-admin not installed. Run: pip install firebase-admin")
    exit(1)


def find_credentials():
    """Find Firebase credentials file"""
    search_paths = [
        os.environ.get('VEO_LICENSE_CONFIG'),
        os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'),
        Path(__file__).parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
        Path(__file__).parent / "00_ADMIN" / "firebase-credentials.json",
        Path(__file__).parent.parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
        Path(__file__).parent.parent / "00_ADMIN" / "firebase-credentials.json",
        Path.home() / ".veoauto" / "firebase-credentials.json",
    ]
    
    for path in search_paths:
        if path and Path(path).exists():
            return Path(path)
    
    return None


def cleanup_expired_keys(dry_run: bool = False):
    """Mark expired keys as 'e' (expired)"""
    
    # Initialize Firebase
    cred_path = find_credentials()
    if not cred_path:
        print("❌ Firebase credentials not found!")
        return
    
    if not firebase_admin._apps:
        cred = credentials.Certificate(str(cred_path))
        firebase_admin.initialize_app(cred)
    
    db = firestore.client()
    now = datetime.now()
    
    print("=" * 60)
    print(f"VEO License Cleanup - {now.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    print()
    
    if dry_run:
        print("🔍 DRY RUN MODE - No changes will be made\n")
    
    # Query active keys that have expired
    expired_docs = db.collection("_lic") \
        .where("_st", "==", "a") \
        .where("_exp", "<", now) \
        .stream()
    
    count = 0
    for doc in expired_docs:
        data = doc.to_dict()
        exp_date = data.get('_exp')
        mid = data.get('_mid', '????')[:8] if data.get('_mid') else '????'
        email = data.get('_em', 'N/A')
        
        print(f"⏰ Key: {doc.id[:35]}...")
        print(f"   Machine ID: {mid}")
        print(f"   Email: {email}")
        if exp_date:
            print(f"   Expired on: {exp_date.strftime('%Y-%m-%d')}")
        
        if not dry_run:
            doc.reference.update({
                "_st": "e",  # expired
                "_expired_at": firestore.SERVER_TIMESTAMP
            })
            print(f"   ✅ Marked as expired")
        else:
            print(f"   📝 Would mark as expired")
        
        print()
        count += 1
    
    print("-" * 60)
    if dry_run:
        print(f"📊 Found: {count} expired keys")
        print(f"   Run without --dry-run to mark them as expired")
    else:
        print(f"✅ Cleaned: {count} keys marked as expired")
    print("=" * 60)


def list_status_summary():
    """Show summary of all keys by status"""
    
    cred_path = find_credentials()
    if not cred_path:
        print("❌ Firebase credentials not found!")
        return
    
    if not firebase_admin._apps:
        cred = credentials.Certificate(str(cred_path))
        firebase_admin.initialize_app(cred)
    
    db = firestore.client()
    
    # Count by status
    all_docs = db.collection("_lic").stream()
    
    stats = {"a": 0, "r": 0, "e": 0, "s": 0, "other": 0}
    total = 0
    
    for doc in all_docs:
        data = doc.to_dict()
        status = data.get('_st', 'other')
        if status in stats:
            stats[status] += 1
        else:
            stats['other'] += 1
        total += 1
    
    print("\n📊 License Status Summary:")
    print("-" * 40)
    print(f"  ✅ Active (a):    {stats['a']}")
    print(f"  ❌ Revoked (r):   {stats['r']}")
    print(f"  ⏰ Expired (e):   {stats['e']}")
    print(f"  ⏸️  Suspended (s): {stats['s']}")
    if stats['other'] > 0:
        print(f"  ❓ Other:        {stats['other']}")
    print("-" * 40)
    print(f"  📦 Total:        {total}")


def main():
    parser = argparse.ArgumentParser(description="VEO License Cleanup Tool")
    parser.add_argument("--dry-run", "-d", action="store_true", 
                       help="Preview changes without applying")
    parser.add_argument("--summary", "-s", action="store_true",
                       help="Show status summary only")
    
    args = parser.parse_args()
    
    if args.summary:
        list_status_summary()
    else:
        cleanup_expired_keys(dry_run=args.dry_run)
        list_status_summary()


if __name__ == "__main__":
    main()
