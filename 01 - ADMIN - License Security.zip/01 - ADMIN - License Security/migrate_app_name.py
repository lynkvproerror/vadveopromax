#!/usr/bin/env python3
"""
🔄 App Migration Script - Firebase License Key
==============================================

Đổi tên app (_app field) cho tất cả license keys trong Firebase.
Sử dụng khi đổi tên app trong App Manager.

Usage:
    python migrate_app_name.py OLD_NAME NEW_NAME [--dry-run]

Examples:
    python migrate_app_name.py VEO VEO_PRO --dry-run
    python migrate_app_name.py CCT CAPCUT_TOOL
"""

import os
import sys
from pathlib import Path

# Firebase Admin SDK
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
except ImportError:
    print("❌ Cần cài firebase-admin: pip install firebase-admin")
    sys.exit(1)


COLLECTION = "_lic"


def find_credentials() -> Path:
    """Auto-discover Firebase credentials"""
    admin_dir = Path(__file__).parent
    
    # Check environment
    for env in ['VEO_LICENSE_CONFIG', 'GOOGLE_APPLICATION_CREDENTIALS']:
        path = os.environ.get(env)
        if path and Path(path).exists():
            return Path(path)
    
    # Auto-discover JSON files
    for json_file in admin_dir.rglob("*.json"):
        try:
            import json
            data = json.loads(json_file.read_text(encoding='utf-8'))
            if all(k in data for k in ("type", "project_id", "private_key_id")):
                return json_file
        except:
            pass
    
    return None


def migrate_app_name(old_name: str, new_name: str, dry_run: bool = False):
    """
    Migrate all license keys from OLD_NAME to NEW_NAME
    
    Args:
        old_name: Current app name (e.g. 'VEO')
        new_name: New app name (e.g. 'VEO_PRO')
        dry_run: If True, only show what would be changed
    """
    print(f"\n{'='*60}")
    print(f"🔄 App Migration: '{old_name}' → '{new_name}'")
    print(f"{'='*60}\n")
    
    # Connect to Firebase
    cred_path = find_credentials()
    if not cred_path:
        print("❌ Không tìm thấy Firebase credentials!")
        return False
    
    print(f"📂 Using credentials: {cred_path.name}")
    
    if not firebase_admin._apps:
        cred = credentials.Certificate(str(cred_path))
        firebase_admin.initialize_app(cred)
    
    db = firestore.client()
    
    # Query keys with old app name
    print(f"\n🔍 Tìm kiếm keys với _app='{old_name}'...")
    
    query = db.collection(COLLECTION).where("_app", "==", old_name)
    docs = list(query.stream())
    
    if not docs:
        print(f"⚠️ Không tìm thấy key nào với _app='{old_name}'")
        
        # Check if there are keys without _app field
        all_docs = list(db.collection(COLLECTION).stream())
        no_app_count = sum(1 for d in all_docs if '_app' not in d.to_dict())
        
        if no_app_count > 0:
            print(f"ℹ️ Có {no_app_count} keys không có field _app")
            print(f"   Chạy: python migrate_app_name.py --add-missing {new_name}")
        
        return True
    
    print(f"✅ Tìm thấy {len(docs)} keys cần migrate\n")
    
    # Show preview
    print(f"{'Key ID':<25} {'Client':<20} {'Status'}")
    print("-" * 60)
    
    for doc in docs[:10]:  # Show first 10
        data = doc.to_dict()
        client = data.get('_cn', '') or ''
        status = {"a": "Active", "r": "Revoked", "e": "Expired"}.get(data.get('_st'), data.get('_st', ''))
        print(f"{doc.id[:24]:<25} {client[:19]:<20} {status}")
    
    if len(docs) > 10:
        print(f"... và {len(docs) - 10} keys khác")
    
    print()
    
    # Dry run check
    if dry_run:
        print("🔶 DRY RUN MODE - Không thay đổi gì")
        print(f"   Sẽ update {len(docs)} keys: _app='{old_name}' → _app='{new_name}'")
        return True
    
    # Confirm
    print(f"⚠️ SẼ CẬP NHẬT {len(docs)} KEYS TRONG FIREBASE!")
    confirm = input(f"Nhập 'YES' để xác nhận: ")
    
    if confirm != "YES":
        print("❌ Đã hủy migration")
        return False
    
    # Execute migration
    print(f"\n🚀 Đang migrate...")
    
    batch = db.batch()
    count = 0
    
    for doc in docs:
        doc_ref = db.collection(COLLECTION).document(doc.id)
        batch.update(doc_ref, {"_app": new_name})
        count += 1
        
        # Commit every 500 (Firestore limit)
        if count % 500 == 0:
            batch.commit()
            batch = db.batch()
            print(f"   ✓ Đã migrate {count}/{len(docs)} keys...")
    
    # Commit remaining
    if count % 500 != 0:
        batch.commit()
    
    print(f"\n✅ HOÀN TẤT! Đã migrate {count} keys từ '{old_name}' → '{new_name}'")
    return True


def add_missing_app(app_name: str, dry_run: bool = False):
    """Add _app field to keys that don't have it"""
    print(f"\n{'='*60}")
    print(f"➕ Thêm _app='{app_name}' cho keys thiếu field")
    print(f"{'='*60}\n")
    
    cred_path = find_credentials()
    if not cred_path:
        print("❌ Không tìm thấy Firebase credentials!")
        return False
    
    if not firebase_admin._apps:
        cred = credentials.Certificate(str(cred_path))
        firebase_admin.initialize_app(cred)
    
    db = firestore.client()
    
    # Find keys without _app
    all_docs = list(db.collection(COLLECTION).stream())
    missing = [(d.id, d.to_dict()) for d in all_docs if '_app' not in d.to_dict()]
    
    if not missing:
        print("✅ Tất cả keys đều đã có field _app")
        return True
    
    print(f"🔍 Tìm thấy {len(missing)} keys thiếu _app\n")
    
    if dry_run:
        print(f"🔶 DRY RUN - Sẽ thêm _app='{app_name}' cho {len(missing)} keys")
        return True
    
    confirm = input(f"Thêm _app='{app_name}' cho {len(missing)} keys? (y/n): ")
    if confirm.lower() != 'y':
        return False
    
    batch = db.batch()
    for i, (doc_id, data) in enumerate(missing):
        doc_ref = db.collection(COLLECTION).document(doc_id)
        batch.update(doc_ref, {"_app": app_name})
        
        if (i + 1) % 500 == 0:
            batch.commit()
            batch = db.batch()
    
    batch.commit()
    print(f"✅ Đã thêm _app='{app_name}' cho {len(missing)} keys")
    return True


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    
    dry_run = "--dry-run" in sys.argv
    
    if sys.argv[1] == "--add-missing":
        if len(sys.argv) < 3:
            print("Usage: python migrate_app_name.py --add-missing APP_NAME")
            sys.exit(1)
        add_missing_app(sys.argv[2], dry_run)
    else:
        if len(sys.argv) < 3:
            print("Usage: python migrate_app_name.py OLD_NAME NEW_NAME [--dry-run]")
            sys.exit(1)
        migrate_app_name(sys.argv[1], sys.argv[2], dry_run)


if __name__ == "__main__":
    main()
