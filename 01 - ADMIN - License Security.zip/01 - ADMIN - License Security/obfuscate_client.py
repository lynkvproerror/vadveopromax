"""
PyArmor Obfuscation Script for VEO Client
==========================================

This script obfuscates client-side Python files to protect:
- License validation logic
- API keys (even though already AES-256 encrypted)
- Security algorithms

Usage:
    python obfuscate_client.py

Output:
    ./dist/client/  - Obfuscated client files ready for distribution

Author: VEO Security Team
"""

import os
import shutil
import subprocess
from pathlib import Path


# ============================================================
# CONFIGURATION
# ============================================================

# Files to obfuscate
CLIENT_FILES = [
    "license_client.py",
    "firebase_rest_client.py",
    "_encrypted_api_keys.py",
    "permissions.py",
    "trial_protection.py",
]

# Source and output directories
SOURCE_DIR = Path(__file__).parent / "client"
OUTPUT_DIR = Path(__file__).parent / "dist" / "client"


# ============================================================
# OBFUSCATION
# ============================================================

def clean_output():
    """Clean previous build."""
    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"✅ Cleaned output directory: {OUTPUT_DIR}")


def obfuscate_files():
    """Obfuscate client files using PyArmor."""
    print("\n🔐 Obfuscating client files...")
    
    for filename in CLIENT_FILES:
        source_file = SOURCE_DIR / filename
        
        if not source_file.exists():
            print(f"⚠️ Skip: {filename} (not found)")
            continue
        
        print(f"  Processing: {filename}")
        
        # PyArmor obfuscate command
        cmd = [
            "pyarmor", "gen",
            "--output", str(OUTPUT_DIR),
            str(source_file)
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                print(f"    ✅ {filename} obfuscated")
            else:
                print(f"    ❌ {filename} failed: {result.stderr}")
        except Exception as e:
            print(f"    ❌ {filename} error: {e}")


def copy_additional_files():
    """Copy non-Python files that are needed."""
    # Add any additional files here if needed
    pass


def verify_output():
    """Verify obfuscated files."""
    print("\n📋 Verifying output...")
    
    obfuscated = list(OUTPUT_DIR.glob("*.py"))
    print(f"  Found {len(obfuscated)} obfuscated files:")
    
    for f in obfuscated:
        size = f.stat().st_size
        print(f"    {f.name}: {size:,} bytes")
    
    return len(obfuscated) > 0


def main():
    print("=" * 60)
    print("🔐 VEO Client Obfuscation Tool")
    print("=" * 60)
    
    # Step 1: Clean
    clean_output()
    
    # Step 2: Obfuscate
    obfuscate_files()
    
    # Step 3: Copy additional
    copy_additional_files()
    
    # Step 4: Verify
    if verify_output():
        print("\n" + "=" * 60)
        print("✅ Obfuscation complete!")
        print(f"📁 Output: {OUTPUT_DIR}")
        print("=" * 60)
    else:
        print("\n❌ Obfuscation failed!")


if __name__ == "__main__":
    main()
