"""
License Backend - Secure Connection Layer
Hides the actual license platform to prevent reverse engineering
"""

import os
import sys
from pathlib import Path

# Obfuscated module names to hide platform
try:
    # Dynamically import to hide from static analysis
    import importlib
    _fb = importlib.import_module('firebase_admin')
    _creds = importlib.import_module('firebase_admin.credentials')
    _fs = importlib.import_module('firebase_admin.firestore')
except ImportError:
    _fb = None
    _creds = None
    _fs = None


class LicenseBackend:
    """
    Abstract license backend - hides implementation details
    Do not expose platform name in error messages or logs
    """
    
    # Obfuscated paths - do not use obvious names
    _CONFIG_PATHS = [
        Path(__file__).parent / "_cfg" / "auth.dat",
        Path(os.environ.get('APPDATA', '')) / "VEO" / "_sys" / "auth.dat",
    ]
    
    def __init__(self):
        self._client = None
        self._initialized = False
        self._init_backend()
    
    def _find_config(self) -> Path:
        """Find configuration file in multiple locations"""
        # First check environment variable (for production)
        env_path = os.environ.get('VEO_LICENSE_CONFIG')
        if env_path and Path(env_path).exists():
            return Path(env_path)
        
        # Check predefined paths
        for path in self._CONFIG_PATHS:
            if path.exists():
                return path
        
        # Development fallback (not for production)
        dev_path = Path(__file__).parent.parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json"
        if dev_path.exists():
            return dev_path
        
        return None
    
    def _init_backend(self):
        """Initialize backend connection"""
        if _fb is None:
            self._initialized = False
            return
        
        try:
            config_path = self._find_config()
            if config_path is None:
                self._initialized = False
                return
            
            # Check if already initialized
            if not _fb._apps:
                cred = _creds.Certificate(str(config_path))
                _fb.initialize_app(cred)
            
            self._client = _fs.client()
            self._initialized = True
            
        except Exception:
            # Generic error - don't expose platform
            self._initialized = False
    
    def is_connected(self) -> bool:
        """Check if backend is connected"""
        return self._initialized and self._client is not None
    
    def validate_key(self, key: str, machine_id: str) -> dict:
        """Validate license key against backend"""
        if not self.is_connected():
            return {"valid": False, "error": "offline"}
        
        try:
            # Obfuscated collection name
            doc = self._client.collection('_lic').document(key).get()
            
            if not doc.exists:
                return {"valid": False, "error": "invalid"}
            
            data = doc.to_dict()
            
            # Check machine binding
            if data.get('_mid') and data['_mid'] != machine_id:
                return {"valid": False, "error": "bound"}
            
            # Check expiry
            from datetime import datetime
            if data.get('_exp') and data['_exp'].timestamp() < datetime.now().timestamp():
                return {"valid": False, "error": "expired"}
            
            # Check status
            if data.get('_st') == 'r':  # revoked
                return {"valid": False, "error": "revoked"}
            
            return {
                "valid": True,
                "tier": data.get('_t', 'trial'),
                "expires": data.get('_exp')
            }
            
        except Exception:
            return {"valid": False, "error": "network"}
    
    def activate_key(self, key: str, machine_id: str) -> dict:
        """Activate a license key"""
        if not self.is_connected():
            return {"success": False, "error": "offline"}
        
        try:
            doc_ref = self._client.collection('_lic').document(key)
            doc = doc_ref.get()
            
            if not doc.exists:
                return {"success": False, "error": "invalid"}
            
            data = doc.to_dict()
            
            # Already bound to different machine
            if data.get('_mid') and data['_mid'] != machine_id:
                return {"success": False, "error": "bound"}
            
            # Bind to machine
            doc_ref.update({
                '_mid': machine_id,
                '_st': 'a',  # active
                '_act': _fs.SERVER_TIMESTAMP
            })
            
            return {
                "success": True,
                "tier": data.get('_t', 'trial')
            }
            
        except Exception:
            return {"success": False, "error": "network"}


def test_connection():
    """Test backend connection - Development only"""
    print("=" * 50)
    print("License Backend Connection Test")
    print("=" * 50)
    
    backend = LicenseBackend()
    
    if backend.is_connected():
        print("✅ Backend connected successfully")
        print("✅ Ready for license validation")
    else:
        print("❌ Backend connection failed")
        print("   Check configuration and network")
    
    print("=" * 50)
    return backend.is_connected()


if __name__ == "__main__":
    test_connection()
