"""
API Key Encryptor - Admin Utility
=================================

This utility generates encrypted API keys for embedding in the client app.
Run this ONLY from admin machine, NEVER distribute this file!

Usage:
    python api_key_encryptor.py --primary <PRIMARY_API_KEY> --backup <BACKUP_API_KEY>
    
Output:
    Generates encrypted key code to paste into firebase_rest_client.py

Author: VEO Security Team
"""

import argparse
from datetime import datetime


def xor_encrypt(data: str, key: bytes) -> bytes:
    """XOR encrypt string with key."""
    data_bytes = data.encode('utf-8')
    result = bytearray(len(data_bytes))
    for i in range(len(data_bytes)):
        result[i] = data_bytes[i] ^ key[i % len(key)]
    return bytes(result)


def generate_encrypted_config(primary_key: str, backup_key: str) -> str:
    """Generate Python code with encrypted API keys."""
    
    # Static encryption key (obfuscated in code)
    static_key = b"VE0_PR0_MAX_2026"  # 16 bytes
    
    # Encrypt keys
    primary_encrypted = xor_encrypt(primary_key, static_key)
    backup_encrypted = xor_encrypt(backup_key, static_key)
    
    # Generate code
    code = f'''
# ============================================================
# AUTO-GENERATED ENCRYPTED API KEYS
# Generated: {datetime.now().isoformat()}
# DO NOT EDIT MANUALLY!
# ============================================================

class _EncryptedKeys:
    """Encrypted API keys - decrypted at runtime only."""
    
    # XOR encryption key (obfuscated)
    _K = b"VE0_PR0_MAX_2026"
    
    # Encrypted API keys
    _P = {primary_encrypted}
    _B = {backup_encrypted}
    
    @classmethod
    def _d(cls, e: bytes) -> str:
        """Decrypt."""
        r = bytearray(len(e))
        for i in range(len(e)):
            r[i] = e[i] ^ cls._K[i % len(cls._K)]
        return bytes(r).decode('utf-8')
    
    @classmethod
    def get_primary(cls) -> str:
        return cls._d(cls._P)
    
    @classmethod
    def get_backup(cls) -> str:
        return cls._d(cls._B)


# Usage in SecureFirebaseConfig:
#   primary_key = _EncryptedKeys.get_primary()
#   backup_key = _EncryptedKeys.get_backup()
'''
    return code


def main():
    parser = argparse.ArgumentParser(description="Encrypt Firebase API keys for client app")
    parser.add_argument('--primary', '-p', required=True, help='Primary Firebase Web API Key')
    parser.add_argument('--backup', '-b', required=True, help='Backup Firebase Web API Key')
    parser.add_argument('--output', '-o', help='Output file (default: stdout)')
    
    args = parser.parse_args()
    
    print("🔐 API Key Encryptor")
    print("=" * 50)
    print(f"Primary Key Length: {len(args.primary)} chars")
    print(f"Backup Key Length: {len(args.backup)} chars")
    print()
    
    code = generate_encrypted_config(args.primary, args.backup)
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(code)
        print(f"✅ Encrypted keys saved to: {args.output}")
    else:
        print("Generated Code:")
        print("=" * 50)
        print(code)
    
    print()
    print("⚠️  IMPORTANT:")
    print("   1. Copy the generated code to firebase_rest_client.py")
    print("   2. Update SecureFirebaseConfig to use _EncryptedKeys")
    print("   3. Delete this output after copying")


if __name__ == "__main__":
    # Interactive mode if no args
    import sys
    if len(sys.argv) == 1:
        print("🔐 API Key Encryptor - Interactive Mode")
        print("=" * 50)
        print()
        print("Enter your Firebase Web API Keys:")
        print("(Get from Firebase Console > Project Settings > General > Web API Key)")
        print()
        
        primary = input("Primary API Key (veo-pro-max): ").strip()
        backup = input("Backup API Key (veoauto-f54b5): ").strip()
        
        if primary and backup:
            code = generate_encrypted_config(primary, backup)
            print()
            print("=" * 50)
            print("Generated Code:")
            print("=" * 50)
            print(code)
            
            # Save to file
            save = input("\nSave to file? (y/n): ").strip().lower()
            if save == 'y':
                filename = "encrypted_keys.py"
                with open(filename, 'w') as f:
                    f.write(code)
                print(f"✅ Saved to: {filename}")
        else:
            print("❌ Both keys required!")
    else:
        main()
