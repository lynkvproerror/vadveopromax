"""
VEO License Manager GUI
PySide6-based tool for managing license keys on Firebase

Requirements:
    pip install PySide6 firebase-admin

Usage:
    python license_manager_gui.py
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTableWidget, QTableWidgetItem, QPushButton, QLabel, QLineEdit,
    QComboBox, QSpinBox, QTextEdit, QDialog, QDialogButtonBox,
    QFormLayout, QGroupBox, QMessageBox, QStatusBar, QHeaderView,
    QSplitter, QFrame, QDateEdit, QCheckBox  # 🆕 Added QCheckBox
)
from PySide6.QtCore import Qt, QThread, Signal, QDate
from PySide6.QtGui import QFont, QColor, QKeySequence, QShortcut

# Import our license modules
from license_keygen import LicenseKeyGenerator, LicenseTier

# Firebase
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False


# ============================================================
# DARK THEME STYLESHEET
# ============================================================

DARK_STYLESHEET = """
QMainWindow, QDialog {
    background-color: #1e1e2e;
    color: #cdd6f4;
}

QLabel {
    color: #cdd6f4;
}

QTableWidget {
    background-color: #2d2d3d;
    color: #cdd6f4;
    gridline-color: #45475a;
    selection-background-color: #6c7086;
    border: 1px solid #45475a;
    border-radius: 4px;
}

QTableWidget::item {
    padding: 8px;
}

QTableWidget::item:selected {
    background-color: #6c7086;
}

QHeaderView::section {
    background-color: #313244;
    color: #89b4fa;
    padding: 8px;
    border: 1px solid #45475a;
    font-weight: bold;
}

QPushButton {
    background-color: #89b4fa;
    color: #1e1e2e;
    border: none;
    border-radius: 4px;
    padding: 8px 16px;
    font-weight: bold;
}

QPushButton:hover {
    background-color: #b4befe;
}

QPushButton:pressed {
    background-color: #74c7ec;
}

QPushButton:disabled {
    background-color: #45475a;
    color: #6c7086;
}

QPushButton#dangerBtn {
    background-color: #f38ba8;
}

QPushButton#dangerBtn:hover {
    background-color: #eba0ac;
}

QLineEdit, QTextEdit, QComboBox, QSpinBox, QDateEdit {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 4px;
    padding: 8px;
}

QLineEdit:focus, QTextEdit:focus, QComboBox:focus {
    border-color: #89b4fa;
}

QGroupBox {
    border: 1px solid #45475a;
    border-radius: 4px;
    margin-top: 12px;
    padding-top: 12px;
    color: #89b4fa;
    font-weight: bold;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}

QStatusBar {
    background-color: #313244;
    color: #a6adc8;
}

QComboBox::drop-down {
    border: none;
    width: 20px;
}

QComboBox QAbstractItemView {
    background-color: #313244;
    color: #cdd6f4;
    selection-background-color: #6c7086;
}

QScrollBar:vertical {
    background-color: #2d2d3d;
    width: 12px;
    border-radius: 6px;
}

QScrollBar::handle:vertical {
    background-color: #45475a;
    border-radius: 6px;
    min-height: 20px;
}

QScrollBar::handle:vertical:hover {
    background-color: #6c7086;
}
"""


# ============================================================
# FIREBASE MANAGER
# ============================================================

class FirebaseManager:
    """Manages Firebase Firestore connection and operations with DUAL FIREBASE support"""
    
    COLLECTION = "_lic"
    
    def __init__(self):
        self.db = None
        self.backup_db = None
        self.connected = False
        self.which_db = None  # "primary" or "backup"
    
    def find_credentials(self) -> Optional[Path]:
        """Find Firebase credentials file (legacy fallback)"""
        search_paths = [
            os.environ.get('VEO_LICENSE_CONFIG'),
            os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'),
            # Direct path in same folder as script
            Path(__file__).parent / "levanlinh.kma" / "veo-pro-max-firebase-adminsdk-fbsvc-1e4a966c51.json",
            Path(__file__).parent / "lynkv.pro" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
            Path(__file__).parent / "firebase-credentials.json",
            Path.home() / ".veoauto" / "firebase-credentials.json",
        ]
        
        for path in search_paths:
            if path and Path(path).exists():
                return Path(path)
        return None
    
    def connect(self) -> bool:
        """Connect to Firebase with FAILOVER support"""
        if not FIREBASE_AVAILABLE:
            return False
        
        # Try using firebase_config module for dual-Firebase
        try:
            from firebase_config import get_failover_db, get_backup_db
            
            # Use failover logic (tries Primary, falls back to Backup)
            self.db, self.which_db = get_failover_db()
            
            if self.db:
                self.connected = True
                # Also get backup for sync later
                self.backup_db = get_backup_db() if self.which_db == "primary" else None
                return True
        except ImportError:
            pass  # Fall back to legacy
        except Exception as e:
            print(f"Failover error: {e}")
        
        # Legacy fallback
        cred_path = self.find_credentials()
        if not cred_path:
            return False
        
        try:
            if not firebase_admin._apps:
                cred = credentials.Certificate(str(cred_path))
                firebase_admin.initialize_app(cred)
            
            self.db = firestore.client()
            self.connected = True
            self.which_db = "legacy"
            return True
        except Exception as e:
            print(f"Firebase error: {e}")
            return False
    
    def get_connection_info(self) -> str:
        """Get which database is being used"""
        if not self.connected:
            return "Not connected"
        return f"Connected to {self.which_db.upper()}"
    
    def get_all_keys(self) -> list:
        """Get all license keys"""
        if not self.connected:
            return []
        
        docs = self.db.collection(self.COLLECTION).stream()
        keys = []
        
        for doc in docs:
            data = doc.to_dict()
            data['id'] = doc.id
            keys.append(data)
        
        return keys
    
    def create_key(self, machine_id: str, tier: LicenseTier, days: int, 
                   email: str = None, note: str = None, client_name: str = None,
                   role: int = 1, app_id: str = "VEO") -> str:  # 🆕 app_id parameter
        """Create a new license key with role and app"""
        from license_keygen import UserRole
        user_role = UserRole(role)
        
        key, metadata = LicenseKeyGenerator.generate(machine_id, tier, days, role=user_role)
        
        doc_data = {
            "_t": metadata['tier'],
            "_st": "a",
            "_cr": firestore.SERVER_TIMESTAMP,
            "_exp": datetime.fromisoformat(metadata['expires']),
            "_mid": metadata['machine_id'],
            "_em": email,
            "_nt": note,
            "_dur": days,
            "_cn": client_name,  # Client name for easier management
            "_role": role,  # User role (0=Trial, 1=Premium, 2=Tester)
            "_app": app_id,  # 🆕 Multi-app support
        }
        
        self.db.collection(self.COLLECTION).document(key).set(doc_data)
        return key
    
    def revoke_key(self, key_id: str, reason: str = "admin") -> bool:
        """Revoke a license key"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.COLLECTION).document(key_id).update({
                "_st": "r",
                "_rv_at": firestore.SERVER_TIMESTAMP,
                "_rv_reason": reason
            })
            return True
        except:
            return False
    
    def delete_key(self, key_id: str) -> bool:
        """Delete a license key permanently"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.COLLECTION).document(key_id).delete()
            return True
        except:
            return False
    
    def update_key(self, key_id: str, updates: dict) -> bool:
        """Update key fields"""
        if not self.connected:
            return False
        
        try:
            self.db.collection(self.COLLECTION).document(key_id).update(updates)
            return True
        except:
            return False
    
    def get_summary(self) -> dict:
        """Get keys summary by status"""
        keys = self.get_all_keys()
        summary = {"active": 0, "revoked": 0, "expired": 0, "total": len(keys)}
        
        now = datetime.now()
        for key in keys:
            status = key.get('_st', '')
            exp = key.get('_exp')
            
            if status == 'r':
                summary['revoked'] += 1
            elif exp and hasattr(exp, 'timestamp') and datetime.fromtimestamp(exp.timestamp()) < now:
                summary['expired'] += 1
            elif status == 'a':
                summary['active'] += 1
        
        return summary
    
    def cleanup_expired_keys(self) -> int:
        """
        Mark all expired keys as 'e' (expired).
        Returns number of keys marked.
        """
        if not self.connected:
            return 0
        
        now = datetime.now()
        count = 0
        
        # Query active keys that have expired
        try:
            from google.cloud.firestore_v1.base_query import FieldFilter
            expired_docs = self.db.collection(self.COLLECTION) \
                .where(filter=FieldFilter("_st", "==", "a")) \
                .where(filter=FieldFilter("_exp", "<", now)) \
                .stream()
            
            for doc in expired_docs:
                doc.reference.update({
                    "_st": "e",  # expired
                    "_expired_at": firestore.SERVER_TIMESTAMP
                })
                count += 1
        except Exception as e:
            print(f"Cleanup error: {e}")
        
        return count
    
    def delete_expired_keys(self, include_revoked: bool = False, backup_dir: str = None) -> tuple:
        """
        Permanently DELETE all expired keys (and optionally revoked).
        Creates backup report BEFORE deletion.
        
        Args:
            include_revoked: Also delete revoked keys
            backup_dir: Directory to save backup reports (default: ~/.veoauto/backups/)
            
        Returns:
            (deleted_count, backup_path)
        """
        if not self.connected:
            return 0, None
        
        # Default backup directory
        if backup_dir is None:
            backup_dir = Path.home() / ".veoauto" / "backups"
        else:
            backup_dir = Path(backup_dir)
        
        now = datetime.now()
        
        # Create date-organized folder: backups/2026/02/02/
        date_folder = backup_dir / now.strftime("%Y") / now.strftime("%m") / now.strftime("%d")
        date_folder.mkdir(parents=True, exist_ok=True)
        
        # Collect keys to delete with full data
        keys_to_delete = []
        
        try:
            all_docs = self.db.collection(self.COLLECTION).stream()
            
            for doc in all_docs:
                data = doc.to_dict()
                status = data.get('_st', '')
                exp = data.get('_exp')
                
                should_delete = False
                delete_reason = ""
                
                # Check expired status
                if status == 'e':
                    should_delete = True
                    delete_reason = "expired_status"
                
                # Check actually expired (but not marked)
                if exp and hasattr(exp, 'timestamp'):
                    if datetime.fromtimestamp(exp.timestamp()) < now:
                        should_delete = True
                        delete_reason = "expired_date"
                
                # Include revoked if requested
                if include_revoked and status == 'r':
                    should_delete = True
                    delete_reason = "revoked"
                
                if should_delete:
                    # Convert Firestore types to JSON-serializable
                    record = {
                        "key_id": doc.id,
                        "delete_reason": delete_reason,
                        "deleted_at": now.isoformat(),
                        "original_data": {}
                    }
                    
                    # Safely convert all fields
                    for k, v in data.items():
                        if hasattr(v, 'isoformat'):  # datetime
                            record["original_data"][k] = v.isoformat()
                        elif hasattr(v, 'timestamp'):  # Firestore Timestamp
                            record["original_data"][k] = datetime.fromtimestamp(v.timestamp()).isoformat()
                        else:
                            record["original_data"][k] = v
                    
                    # VND Pricing tier mapping
                    tier_map = {
                        "TRIA": "Trial (7d)", "1M": "1 Tháng", "3M": "3 Tháng",
                        "6M": "6 Tháng", "1Y": "1 Năm", "LT": "Vĩnh viễn"
                    }
                    record["tier_name"] = tier_map.get(data.get('_t', ''), data.get('_t', ''))
                    
                    keys_to_delete.append((doc, record))
                    
        except Exception as e:
            print(f"Collect keys error: {e}")
            return 0, None
        
        if not keys_to_delete:
            return 0, None
        
        # Create backup report
        backup_filename = now.strftime("deleted_keys_%Y%m%d_%H%M%S.json")
        backup_path = date_folder / backup_filename
        
        # Build full report
        report = {
            "report_info": {
                "generated_at": now.isoformat(),
                "total_deleted": len(keys_to_delete),
                "include_revoked": include_revoked,
                "backup_format_version": "1.0"
            },
            "summary": {
                "expired": sum(1 for _, r in keys_to_delete if r["delete_reason"] in ["expired_status", "expired_date"]),
                "revoked": sum(1 for _, r in keys_to_delete if r["delete_reason"] == "revoked")
            },
            "deleted_keys": [record for _, record in keys_to_delete]
        }
        
        # Save backup BEFORE deleting
        try:
            import json
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            print(f"✅ Backup saved: {backup_path}")
        except Exception as e:
            print(f"❌ Backup failed: {e}")
            return 0, None  # Don't delete if backup fails!
        
        # Now delete from Firebase
        count = 0
        for doc, _ in keys_to_delete:
            try:
                doc.reference.delete()
                count += 1
            except Exception as e:
                print(f"Delete error for {doc.id}: {e}")
        
        return count, str(backup_path)
    
    # =========================================================================
    # LICENSE REQUEST HANDLING
    # =========================================================================
    
    REQUEST_COLLECTION = "_upgrade_requests"
    
    def get_pending_requests(self) -> list:
        """Get all pending upgrade requests"""
        if not self.connected:
            return []
        
        try:
            from google.cloud.firestore_v1.base_query import FieldFilter
            try:
                docs = self.db.collection(self.REQUEST_COLLECTION) \
                    .where(filter=FieldFilter("status", "==", "pending")) \
                    .order_by("requested_at", direction=firestore.Query.DESCENDING) \
                    .stream()
            except Exception:
                # Fallback: no index for ordered query
                docs = self.db.collection(self.REQUEST_COLLECTION) \
                    .where(filter=FieldFilter("status", "==", "pending")) \
                    .stream()
            
            requests = []
            for doc in docs:
                data = doc.to_dict()
                data['id'] = doc.id
                requests.append(data)
            
            return requests
        except Exception as e:
            print(f"Get requests error: {e}")
            return []
    
    def get_all_requests(self) -> list:
        """Get all license requests (all statuses)"""
        if not self.connected:
            return []
        
        try:
            docs = self.db.collection(self.REQUEST_COLLECTION).stream()
            requests = []
            for doc in docs:
                data = doc.to_dict()
                data['id'] = doc.id
                requests.append(data)
            return requests
        except:
            return []
    
    def find_active_key_by_mid(self, machine_id: str):
        """Find existing active license key for a machine ID.
        
        Returns:
            (key_id: str, key_data: dict) or (None, None) if not found
        """
        if not self.connected:
            return None, None
        try:
            results = self.db.collection(self.COLLECTION) \
                .where('_mid', '==', machine_id) \
                .where('_st', '==', 'a') \
                .limit(1).get()
            for doc in results:
                return doc.id, doc.to_dict()
            return None, None
        except:
            return None, None
    
    def approve_request(self, request_id: str, tier: LicenseTier, days: int, 
                        admin_email: str = "admin", role: int = 1, app_id: str = "VEO") -> tuple:
        """
        Approve request with Extend-or-Create logic.
        
        - If active key exists for this MID → extend expiry (time stacking)
        - If no active key → create new key
        - Always deletes request doc after processing
        """
        if not self.connected:
            return False, "Not connected"
        
        try:
            doc_ref = self.db.collection(self.REQUEST_COLLECTION).document(request_id)
            doc = doc_ref.get()
            
            if not doc.exists:
                return False, "Request not found"
            
            data = doc.to_dict()
            machine_id = data.get('machine_id')
            
            if not machine_id:
                return False, "Invalid request: no machine_id"
            
            # ── Check for existing active key ──
            existing_key_id, existing_data = self.find_active_key_by_mid(machine_id)
            
            if existing_key_id and existing_data:
                # ═══ EXTEND: Cộng dồn thời gian ═══
                old_exp = existing_data.get('_exp')
                now = datetime.now()
                
                # If expired → base from today; if still active → base from old expiry
                if hasattr(old_exp, 'timestamp'):
                    base = old_exp if old_exp > now else now
                else:
                    base = now
                
                new_exp = base + timedelta(days=days)
                old_dur = existing_data.get('_dur', 0) or 0
                
                # Update existing key
                self.db.collection(self.COLLECTION).document(existing_key_id).update({
                    '_exp': new_exp,
                    '_dur': old_dur + days,
                    '_t': tier.name,
                    '_nt': f"Extended +{days}d by {admin_email} (was {old_dur}d)",
                })
                
                key = existing_key_id
                result_msg = f"{key}\n\n⏱ Extended: +{days} ngày (tổng {old_dur + days}d)\nHết hạn mới: {new_exp.strftime('%Y-%m-%d %H:%M')}"
            else:
                # ═══ CREATE: Tạo key mới ═══
                from license_keygen import UserRole
                user_role = UserRole(role)
                key, metadata = LicenseKeyGenerator.generate(machine_id, tier, days, role=user_role)
                
                lic_data = {
                    "_t": metadata['tier'],
                    "_st": "a",
                    "_cr": firestore.SERVER_TIMESTAMP,
                    "_exp": datetime.fromisoformat(metadata['expires']),
                    "_mid": machine_id,
                    "_em": data.get('email'),
                    "_cn": data.get('client_name'),
                    "_nt": f"From request {request_id}",
                    "_dur": days,
                    "_role": role,
                    "_app": app_id,
                }
                self.db.collection(self.COLLECTION).document(key).set(lic_data)
                result_msg = key
            
            # ── Delete request doc (auto-cleanup) ──
            doc_ref.delete()
            
            return True, result_msg
            
        except Exception as e:
            return False, str(e)
    
    def reject_request(self, request_id: str, reason: str, admin_email: str = "admin") -> bool:
        """Reject a license request → delete request doc"""
        if not self.connected:
            return False
        
        try:
            # Delete request doc directly (no need to keep rejected requests)
            self.db.collection(self.REQUEST_COLLECTION).document(request_id).delete()
            return True
        except:
            return False
    
    def get_request_summary(self) -> dict:
        """Get summary of requests by status"""
        requests = self.get_all_requests()
        summary = {"pending": 0, "approved": 0, "rejected": 0, "blocked": 0, "total": len(requests)}
        
        for req in requests:
            if req.get('blocked'):
                summary['blocked'] += 1
            else:
                status = req.get('status', 'pending')
                if status in summary:
                    summary[status] += 1
        
        return summary
    
    def block_machine(self, request_id: str, admin_email: str = "admin") -> bool:
        """Block a machine from sending further requests"""
        if not self.connected:
            return False
        try:
            self.db.collection(self.REQUEST_COLLECTION).document(request_id).update({
                "blocked": True,
                "blocked_at": firestore.SERVER_TIMESTAMP,
                "blocked_by": admin_email,
                "status": "blocked"
            })
            return True
        except:
            return False
    
    def unblock_machine(self, request_id: str) -> bool:
        """Unblock a machine → delete the blocked request doc"""
        if not self.connected:
            return False
        try:
            self.db.collection(self.REQUEST_COLLECTION).document(request_id).delete()
            return True
        except:
            return False


# ============================================================
# CREATE KEY DIALOG
# ============================================================

class CreateKeyDialog(QDialog):
    """Dialog for creating new license key"""
    
    def __init__(self, firebase: FirebaseManager, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.created_key = None
        self.setup_ui()
    
    def setup_ui(self):
        self.setWindowTitle("➕ Create New License Key")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        
        form = QFormLayout()
        
        # Machine ID (required)
        self.machine_id_input = QLineEdit()
        self.machine_id_input.setPlaceholderText("e.g., 3946C15B")
        form.addRow("Machine ID *:", self.machine_id_input)
        
        # Client Name (for management)
        self.client_name_input = QLineEdit()
        self.client_name_input.setPlaceholderText("e.g., Nguyễn Văn A")
        form.addRow("Client Name:", self.client_name_input)
        
        # App (multi-app support)
        self.app_combo = QComboBox()
        # Get apps from parent window
        apps = ["VEO", "CCT", "RAT", "G-LABS"]
        if hasattr(self.parent(), 'APPS'):
            apps = self.parent().APPS
        self.app_combo.addItems(apps)
        self.app_combo.setCurrentText("VEO")
        form.addRow("App:", self.app_combo)
        
        # Tier
        self.tier_combo = QComboBox()
        self.tier_combo.addItems(["TRIAL", "ONE_MONTH", "THREE_MONTHS", "SIX_MONTHS", "ONE_YEAR", "LIFETIME"])
        self.tier_combo.setCurrentText("ONE_MONTH")
        self.tier_combo.currentTextChanged.connect(self.on_tier_changed)  # 🆕 Connect signal
        form.addRow("Tier:", self.tier_combo)
        
        # Role 🆕
        self.role_combo = QComboBox()
        self.role_combo.addItems(["TRIAL (0)", "PREMIUM (1)", "TESTER (2)"])
        self.role_combo.setCurrentText("PREMIUM (1)")
        form.addRow("Role:", self.role_combo)
        
        # Duration
        self.days_spin = QSpinBox()
        self.days_spin.setRange(7, 36500)  # Max 100 years for LIFETIME
        self.days_spin.setValue(30)
        self.days_spin.setSuffix(" days")
        form.addRow("Duration:", self.days_spin)
        
        # Email (optional)
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("customer@example.com")
        form.addRow("Email:", self.email_input)
        
        # Note (optional)
        self.note_input = QTextEdit()
        self.note_input.setMaximumHeight(80)
        self.note_input.setPlaceholderText("Admin notes...")
        form.addRow("Note:", self.note_input)
        
        layout.addLayout(form)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.create_key)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def on_tier_changed(self, tier_text: str):
        """Handle tier change: auto-set duration and lock role for TRIAL tier"""
        # Duration mapping for each tier
        TIER_DURATION = {
            "TRIAL": 7,
            "ONE_MONTH": 30,
            "THREE_MONTHS": 90,
            "SIX_MONTHS": 180,
            "ONE_YEAR": 365,
            "LIFETIME": 36500,  # 100 years
        }
        
        # Auto-set duration based on tier
        if tier_text in TIER_DURATION:
            self.days_spin.setValue(TIER_DURATION[tier_text])
        
        if tier_text == "TRIAL":
            # TRIAL tier: TRIAL or TESTER roles only
            current_role = self.role_combo.currentText()
            self.role_combo.clear()
            self.role_combo.addItems(["TRIAL (0)", "TESTER (2)"])
            
            # Restore if valid, else TRIAL
            if current_role in ["TRIAL (0)", "TESTER (2)"]:
                self.role_combo.setCurrentText(current_role)
            else:
                self.role_combo.setCurrentText("TRIAL (0)")
            
            self.role_combo.setEnabled(True)  # Allow choosing TRIAL or TESTER
            self.days_spin.setEnabled(False)  # Duration locked to 7 days
        else:
            # Paid tiers: Only PREMIUM and TESTER roles (no TRIAL)
            current_role = self.role_combo.currentText()
            self.role_combo.clear()
            self.role_combo.addItems(["PREMIUM (1)", "TESTER (2)"])
            
            # Restore selection if valid, else default to PREMIUM
            if current_role in ["PREMIUM (1)", "TESTER (2)"]:
                self.role_combo.setCurrentText(current_role)
            else:
                self.role_combo.setCurrentText("PREMIUM (1)")
            
            self.role_combo.setEnabled(True)
            
            # Lock duration only for LIFETIME
            self.days_spin.setEnabled(tier_text != "LIFETIME")
    
    def create_key(self):
        machine_id = self.machine_id_input.text().strip()
        
        if len(machine_id) < 4:
            QMessageBox.warning(self, "Error", "Machine ID must be at least 4 characters!")
            return
        
        tier = LicenseTier.from_name(self.tier_combo.currentText())
        days = self.days_spin.value()
        email = self.email_input.text().strip() or None
        note = self.note_input.toPlainText().strip() or None
        client_name = self.client_name_input.text().strip() or None
        
        # Parse role from dropdown 🆕
        role_text = self.role_combo.currentText()
        role_code = int(role_text.split("(")[1].rstrip(")"))
        
        # Get app from dropdown
        app = self.app_combo.currentText()
        
        try:
            self.created_key = self.firebase.create_key(
                machine_id, tier, days, email, note, client_name, role=role_code, app_id=app
            )
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create key: {e}")


# ============================================================
# EDIT KEY DIALOG
# ============================================================

class EditKeyDialog(QDialog):
    """Dialog for editing existing license key"""
    
    def __init__(self, firebase: FirebaseManager, key_id: str, key_data: dict, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.key_id = key_id
        self.key_data = key_data
        self.original_expiry = None
        self.setup_ui()
    
    def setup_ui(self):
        self.setWindowTitle(f"✏️ Edit Key: {self.key_id[:25]}...")
        self.setMinimumWidth(450)
        
        layout = QVBoxLayout(self)
        
        # === KEY INFORMATION (readonly) ===
        info_group = QGroupBox("Key Information")
        info_layout = QFormLayout()
        
        key_label = QLineEdit(self.key_id)
        key_label.setReadOnly(True)
        info_layout.addRow("Key:", key_label)
        
        mid_label = QLineEdit(self.key_data.get('_mid', 'N/A'))
        mid_label.setReadOnly(True)
        info_layout.addRow("Machine ID:", mid_label)
        
        # VND Pricing tier mapping
        tier_map = {
            "TRIA": "Trial (7d)", "1M": "1 Tháng", "3M": "3 Tháng",
            "6M": "6 Tháng", "1Y": "1 Năm", "LT": "Vĩnh viễn"
        }
        tier_label = QLineEdit(tier_map.get(self.key_data.get('_t', ''), self.key_data.get('_t', '')))
        tier_label.setReadOnly(True)
        info_layout.addRow("Tier:", tier_label)
        
        # Role (editable)
        self.role_combo = QComboBox()
        self.role_combo.addItems(["TRIAL (0)", "PREMIUM (1)", "TESTER (2)"])
        current_role = self.key_data.get('_role', 1)
        role_index = {0: 0, 1: 1, 2: 2}.get(current_role, 1)
        self.role_combo.setCurrentIndex(role_index)
        info_layout.addRow("Role:", self.role_combo)
        
        # App (editable)
        self.app_combo = QComboBox()
        apps = ["VEO", "CCT", "RAT", "G-LABS"]
        if hasattr(self.parent(), 'APPS'):
            apps = self.parent().APPS
        self.app_combo.addItems(apps)
        current_app = self.key_data.get('_app', 'VEO')
        if current_app in apps:
            self.app_combo.setCurrentText(current_app)
        info_layout.addRow("App:", self.app_combo)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # === LICENSE STATUS (editable) ===
        status_group = QGroupBox("License Status")
        status_layout = QFormLayout()
        
        # Status
        self.status_combo = QComboBox()
        self.status_combo.addItems(["✅ Active", "⏸️ Suspended", "❌ Revoked"])
        current_status = self.key_data.get('_st', 'a')
        status_map = {'a': 0, 's': 1, 'r': 2}
        self.status_combo.setCurrentIndex(status_map.get(current_status, 0))
        status_layout.addRow("Status:", self.status_combo)
        
        # Expiry date with warning
        self.expiry_date = QDateEdit()
        self.expiry_date.setCalendarPopup(True)
        exp = self.key_data.get('_exp')
        if exp and hasattr(exp, 'year'):
            self.original_expiry = QDate(exp.year, exp.month, exp.day)
            self.expiry_date.setDate(self.original_expiry)
        else:
            self.original_expiry = QDate.currentDate().addDays(30)
            self.expiry_date.setDate(self.original_expiry)
        status_layout.addRow("Expires:", self.expiry_date)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        # === CUSTOMER INFO (editable) ===
        customer_group = QGroupBox("Customer Info")
        customer_layout = QFormLayout()
        
        # Client Name
        self.client_name_input = QLineEdit()
        self.client_name_input.setText(self.key_data.get('_cn', '') or '')
        self.client_name_input.setPlaceholderText("e.g., Nguyễn Văn A")
        customer_layout.addRow("Name:", self.client_name_input)
        
        # Email
        self.email_input = QLineEdit()
        self.email_input.setText(self.key_data.get('_em', '') or '')
        self.email_input.setPlaceholderText("customer@example.com")
        customer_layout.addRow("Email:", self.email_input)
        
        # Note
        self.note_input = QTextEdit()
        self.note_input.setMaximumHeight(60)
        self.note_input.setText(self.key_data.get('_nt', '') or '')
        self.note_input.setPlaceholderText("Admin notes...")
        customer_layout.addRow("Note:", self.note_input)
        
        customer_group.setLayout(customer_layout)
        layout.addWidget(customer_group)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.save_changes)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def save_changes(self):
        status_map = {0: 'a', 1: 's', 2: 'r'}
        new_status = status_map[self.status_combo.currentIndex()]
        
        qdate = self.expiry_date.date()
        new_expiry = datetime(qdate.year(), qdate.month(), qdate.day())
        
        # Check if expiry is being extended → show warning
        if qdate > self.original_expiry:
            days_added = self.original_expiry.daysTo(qdate)
            reply = QMessageBox.warning(
                self, "⚠️ Gia hạn License",
                f"Bạn đang GIA HẠN license thêm {days_added} ngày!\n\n"
                f"Ngày hết hạn cũ: {self.original_expiry.toString('yyyy-MM-dd')}\n"
                f"Ngày hết hạn mới: {qdate.toString('yyyy-MM-dd')}\n\n"
                f"Xác nhận gia hạn?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        new_note = self.note_input.toPlainText().strip() or None
        new_email = self.email_input.text().strip() or None
        new_client_name = self.client_name_input.text().strip() or None
        
        # Parse role from dropdown
        role_text = self.role_combo.currentText()
        new_role = int(role_text.split("(")[1].rstrip(")"))
        
        # Get app from dropdown
        new_app = self.app_combo.currentText()
        
        updates = {
            '_st': new_status,
            '_exp': new_expiry,
            '_nt': new_note,
            '_em': new_email,
            '_cn': new_client_name,
            '_role': new_role,
            '_app': new_app,
        }
        
        if self.firebase.update_key(self.key_id, updates):
            self.accept()
        else:
            QMessageBox.critical(self, "Error", "Failed to save changes!")


# ============================================================
# MAIN WINDOW
# ============================================================

class LicenseManagerWindow(QMainWindow):
    """Main application window"""
    
    CONFIG_FILE = Path.home() / ".veoauto" / "config.json"
    
    def __init__(self):
        super().__init__()
        self.firebase = FirebaseManager()
        self.keys_data = []
        self.config = self._load_config()
        
        # Multi-app support
        self.APPS = self.config.get("apps", ["VEO", "CCT", "RAT", "G-LABS"])
        self.app_filter = "All"
        
        self.setup_ui()
        self.connect_firebase()
        self.refresh_keys()
        self.update_requests_badge()  # Show pending requests count on startup
    
    def _load_config(self) -> dict:
        if self.CONFIG_FILE.exists():
            try:
                import json
                return json.loads(self.CONFIG_FILE.read_text(encoding='utf-8'))
            except:
                pass
        return {"apps": ["VEO", "CCT", "RAT", "G-LABS"]}
    
    def _save_config(self):
        self.CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        import json
        self.CONFIG_FILE.write_text(json.dumps(self.config, indent=2), encoding='utf-8')
    
    def setup_ui(self):
        self.setWindowTitle("🔐 VEO License Manager")
        self.setMinimumSize(900, 600)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(12)
        layout.setContentsMargins(12, 12, 12, 12)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_keys)
        toolbar.addWidget(refresh_btn)
        
        create_btn = QPushButton("➕ Create Key")
        create_btn.clicked.connect(self.create_key_dialog)
        toolbar.addWidget(create_btn)
        
        revoke_btn = QPushButton("🗑️ Revoke")
        revoke_btn.setObjectName("dangerBtn")
        revoke_btn.clicked.connect(self.revoke_selected_key)
        toolbar.addWidget(revoke_btn)
        
        delete_btn = QPushButton("❌ Delete")
        delete_btn.setObjectName("dangerBtn")
        delete_btn.clicked.connect(self.delete_selected_key)
        toolbar.addWidget(delete_btn)
        
        # Separator
        separator1 = QWidget()
        separator1.setFixedWidth(20)
        toolbar.addWidget(separator1)
        
        # Cleanup expired button
        cleanup_btn = QPushButton("🧹 Cleanup Expired")
        cleanup_btn.setToolTip("Mark all expired keys and optionally delete them")
        cleanup_btn.clicked.connect(self.cleanup_expired_dialog)
        toolbar.addWidget(cleanup_btn)
        
        # App Filter dropdown
        separator2 = QWidget()
        separator2.setFixedWidth(20)
        toolbar.addWidget(separator2)
        
        app_label = QLabel("🏠 App:")
        toolbar.addWidget(app_label)
        
        from PySide6.QtWidgets import QComboBox
        self.app_filter_combo = QComboBox()
        self.app_filter_combo.addItems(["All"] + self.APPS)
        self.app_filter_combo.setToolTip("Filter licenses by app")
        self.app_filter_combo.currentTextChanged.connect(self.on_app_filter_changed)
        toolbar.addWidget(self.app_filter_combo)
        
        toolbar.addStretch()
        
        # Pending requests button with badge
        self.requests_btn = QPushButton("📬 Requests")
        self.requests_btn.setToolTip("View pending license requests")
        self.requests_btn.clicked.connect(self.show_requests_dialog)
        toolbar.addWidget(self.requests_btn)
        
        summary_btn = QPushButton("📊 Summary")
        summary_btn.clicked.connect(self.show_summary)
        toolbar.addWidget(summary_btn)
        
        # Settings button 🆕
        settings_btn = QPushButton("⚙️ Settings")
        settings_btn.setToolTip("Firebase credentials và backup settings")
        settings_btn.clicked.connect(self.show_settings_dialog)
        toolbar.addWidget(settings_btn)
        
        layout.addLayout(toolbar)
        
        # Splitter for table + details
        splitter = QSplitter(Qt.Horizontal)
        
        # Table - Client first, then Key (full display)
        self.table = QTableWidget()
        self.table.setColumnCount(8)  # Added App, Role columns
        self.table.setHorizontalHeaderLabels(["Client", "Key", "MID", "Tier", "Role", "App", "Status", "Expires"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        
        # Enable interactive column resizing - ALL columns can be dragged
        header = self.table.horizontalHeader()
        header.setSectionsMovable(True)                       # Columns can be reordered by drag
        header.setSectionResizeMode(QHeaderView.Interactive)  # All columns resizable by drag
        header.setStretchLastSection(True)                    # Last column fills remaining space
        
        # Set minimum column widths (can be resized larger)
        self.table.setColumnWidth(0, 100)   # Client
        self.table.setColumnWidth(1, 250)   # Key
        self.table.setColumnWidth(2, 70)    # MID
        self.table.setColumnWidth(3, 45)    # Tier
        self.table.setColumnWidth(4, 65)    # Role
        self.table.setColumnWidth(5, 55)    # App
        self.table.setColumnWidth(6, 50)    # Status
        # Column 7 (Expires) stretches to fill remaining space
        
        self.table.itemSelectionChanged.connect(self.on_key_selected)
        splitter.addWidget(self.table)
        
        # Details panel - organized like Edit dialog
        details_widget = QWidget()
        details_layout = QVBoxLayout(details_widget)
        
        # === KEY INFORMATION ===
        key_info_group = QGroupBox("Key Information")
        key_info_form = QFormLayout()
        
        self.detail_key = QLineEdit()
        self.detail_key.setReadOnly(True)
        key_info_form.addRow("Key:", self.detail_key)
        
        self.detail_mid = QLineEdit()
        self.detail_mid.setReadOnly(True)
        key_info_form.addRow("Machine ID:", self.detail_mid)
        
        self.detail_tier = QLineEdit()
        self.detail_tier.setReadOnly(True)
        key_info_form.addRow("Tier:", self.detail_tier)
        
        self.detail_role = QLineEdit()
        self.detail_role.setReadOnly(True)
        key_info_form.addRow("Role:", self.detail_role)
        
        self.detail_app = QLineEdit()
        self.detail_app.setReadOnly(True)
        key_info_form.addRow("App:", self.detail_app)
        
        key_info_group.setLayout(key_info_form)
        details_layout.addWidget(key_info_group)
        
        # === LICENSE STATUS ===
        status_group = QGroupBox("License Status")
        status_form = QFormLayout()
        
        self.detail_status = QLineEdit()
        self.detail_status.setReadOnly(True)
        status_form.addRow("Status:", self.detail_status)
        
        self.detail_created = QLineEdit()
        self.detail_created.setReadOnly(True)
        status_form.addRow("Created:", self.detail_created)
        
        self.detail_expires = QLineEdit()
        self.detail_expires.setReadOnly(True)
        status_form.addRow("Expires:", self.detail_expires)
        
        status_group.setLayout(status_form)
        details_layout.addWidget(status_group)
        
        # === CUSTOMER INFO ===
        customer_group = QGroupBox("Customer Info")
        customer_form = QFormLayout()
        
        self.detail_client = QLineEdit()
        self.detail_client.setReadOnly(True)
        customer_form.addRow("Name:", self.detail_client)
        
        self.detail_email = QLineEdit()
        self.detail_email.setReadOnly(True)
        customer_form.addRow("Email:", self.detail_email)
        
        self.detail_note = QTextEdit()
        self.detail_note.setReadOnly(True)
        self.detail_note.setMaximumHeight(50)
        customer_form.addRow("Note:", self.detail_note)
        
        customer_group.setLayout(customer_form)
        details_layout.addWidget(customer_group)
        
        # Detail buttons
        detail_buttons = QHBoxLayout()
        
        copy_btn = QPushButton("📋 Copy Key")
        copy_btn.clicked.connect(self.copy_key_to_clipboard)
        detail_buttons.addWidget(copy_btn)
        
        edit_btn = QPushButton("✏️ Edit")
        edit_btn.clicked.connect(self.edit_key_dialog)
        detail_buttons.addWidget(edit_btn)
        
        details_layout.addLayout(detail_buttons)
        details_layout.addStretch()
        
        splitter.addWidget(details_widget)
        splitter.setSizes([600, 300])
        
        layout.addWidget(splitter)
        
        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Starting...")
        
        # Keyboard shortcuts
        QShortcut(QKeySequence("Ctrl+N"), self, self.create_key_dialog)
        QShortcut(QKeySequence("F5"), self, self.refresh_keys)
        QShortcut(QKeySequence("Delete"), self, self.revoke_selected_key)
    
    def connect_firebase(self):
        if self.firebase.connect():
            info = self.firebase.get_connection_info()
            self.status_bar.showMessage(f"✅ {info}")
        else:
            self.status_bar.showMessage("❌ Firebase connection failed!")
            QMessageBox.warning(self, "Warning", 
                "Could not connect to Firebase.\nMake sure credentials file exists.")
    
    def refresh_keys(self):
        all_keys = self.firebase.get_all_keys()
        
        # Filter by app if not "All"
        self.app_filter = self.app_filter_combo.currentText() if hasattr(self, 'app_filter_combo') else "All"
        if self.app_filter and self.app_filter != "All":
            self.keys_data = [k for k in all_keys if k.get('_app') == self.app_filter]
        else:
            self.keys_data = all_keys
        
        self.table.setRowCount(len(self.keys_data))
        
        for i, key_data in enumerate(self.keys_data):
            key_id = key_data.get('id', '')
            client = key_data.get('_cn', '') or ''
            mid = key_data.get('_mid', '')[:8] if key_data.get('_mid') else ''
            tier = key_data.get('_t', '')
            status = key_data.get('_st', '')
            exp = key_data.get('_exp')
            app = key_data.get('_app', 'VEO')  # Multi-app support
            role = key_data.get('_role', 1)  # Default PREMIUM
            
            # Display mappings
            status_display = {"a": "✅", "r": "❌", "e": "⏰", "s": "⏸️"}.get(status, status)
            exp_display = exp.strftime('%Y-%m-%d') if hasattr(exp, 'strftime') else str(exp)[:10] if exp else ''
            role_display = {0: "Trial", 1: "Premium", 2: "Tester"}.get(role, str(role))
            
            # Column order: Client, Key, MID, Tier, Role, App, Status, Expires
            self.table.setItem(i, 0, QTableWidgetItem(client))
            self.table.setItem(i, 1, QTableWidgetItem(key_id))  # Full key, no truncation
            self.table.setItem(i, 2, QTableWidgetItem(mid))
            self.table.setItem(i, 3, QTableWidgetItem(tier))
            self.table.setItem(i, 4, QTableWidgetItem(role_display))
            self.table.setItem(i, 5, QTableWidgetItem(app))
            self.table.setItem(i, 6, QTableWidgetItem(status_display))
            self.table.setItem(i, 7, QTableWidgetItem(exp_display))
        
        summary = self.firebase.get_summary()
        filter_text = f" [{self.app_filter}]" if self.app_filter != "All" else ""
        self.status_bar.showMessage(
            f"✅ Connected | Total: {len(self.keys_data)}{filter_text} | Active: {summary['active']} | Revoked: {summary['revoked']} | Expired: {summary['expired']}"
        )
    
    def on_app_filter_changed(self, value):
        """Handle app filter change"""
        self.app_filter = value
        self.refresh_keys()
    
    def on_key_selected(self):
        rows = self.table.selectedIndexes()
        if not rows:
            return
        
        row = rows[0].row()
        if row < len(self.keys_data):
            data = self.keys_data[row]
            
            self.detail_key.setText(data.get('id', ''))
            self.detail_client.setText(data.get('_cn', '') or '')
            self.detail_mid.setText(data.get('_mid', ''))
            
            # VND Pricing tier mapping
            tier_map = {
                "TRIA": "Trial (7d)", "1M": "1 Tháng", "3M": "3 Tháng",
                "6M": "6 Tháng", "1Y": "1 Năm", "LT": "Vĩnh viễn"
            }
            self.detail_tier.setText(tier_map.get(data.get('_t', ''), data.get('_t', '')))
            
            # Role mapping
            role_map = {0: "Trial", 1: "Premium", 2: "Tester"}
            role = data.get('_role', 1)
            self.detail_role.setText(role_map.get(role, str(role)))
            
            # App
            self.detail_app.setText(data.get('_app', 'VEO'))
            
            status_map = {"a": "Active", "r": "Revoked", "e": "Expired", "s": "Suspended"}
            self.detail_status.setText(status_map.get(data.get('_st', ''), data.get('_st', '')))
            
            cr = data.get('_cr')
            self.detail_created.setText(cr.strftime('%Y-%m-%d %H:%M') if hasattr(cr, 'strftime') else str(cr)[:16] if cr else '')
            
            exp = data.get('_exp')
            self.detail_expires.setText(exp.strftime('%Y-%m-%d') if hasattr(exp, 'strftime') else str(exp)[:10] if exp else '')
            
            self.detail_email.setText(data.get('_em', '') or '')
            self.detail_note.setText(data.get('_nt', '') or '')
    
    def create_key_dialog(self):
        dialog = CreateKeyDialog(self.firebase, self)
        if dialog.exec() == QDialog.Accepted and dialog.created_key:
            QMessageBox.information(self, "Success", 
                f"Key created:\n\n{dialog.created_key}\n\nCopied to clipboard!")
            QApplication.clipboard().setText(dialog.created_key)
            self.refresh_keys()
    
    def edit_key_dialog(self):
        key_id = self.detail_key.text()
        if not key_id:
            QMessageBox.warning(self, "Warning", "Please select a key first!")
            return
        
        # Find key data
        key_data = None
        for data in self.keys_data:
            if data.get('id') == key_id:
                key_data = data
                break
        
        if not key_data:
            return
        
        dialog = EditKeyDialog(self.firebase, key_id, key_data, self)
        if dialog.exec() == QDialog.Accepted:
            self.refresh_keys()
    
    def revoke_selected_key(self):
        key_id = self.detail_key.text()
        if not key_id:
            QMessageBox.warning(self, "Warning", "Please select a key first!")
            return
        
        reply = QMessageBox.question(
            self, "Confirm Revoke",
            f"Are you sure you want to revoke this key?\n\n{key_id[:40]}...",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.revoke_key(key_id, "admin"):
                QMessageBox.information(self, "Success", "Key revoked!")
                self.refresh_keys()
            else:
                QMessageBox.critical(self, "Error", "Failed to revoke key!")
    
    def delete_selected_key(self):
        key_id = self.detail_key.text()
        if not key_id:
            QMessageBox.warning(self, "Warning", "Please select a key first!")
            return
        
        reply = QMessageBox.warning(
            self, "⚠️ Confirm DELETE",
            f"Are you sure you want to PERMANENTLY DELETE this key?\n\n{key_id[:40]}...\n\nThis action cannot be undone!",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.delete_key(key_id):
                QMessageBox.information(self, "Success", "Key deleted!")
                self.refresh_keys()
            else:
                QMessageBox.critical(self, "Error", "Failed to delete key!")
    
    def copy_key_to_clipboard(self):
        key_id = self.detail_key.text()
        if key_id:
            QApplication.clipboard().setText(key_id)
            self.status_bar.showMessage("📋 Key copied to clipboard!", 3000)
    
    def show_summary(self):
        summary = self.firebase.get_summary()
        QMessageBox.information(
            self, "📊 License Summary",
            f"Total Keys: {summary['total']}\n\n"
            f"✅ Active: {summary['active']}\n"
            f"❌ Revoked: {summary['revoked']}\n"
            f"⏰ Expired: {summary['expired']}"
        )
    
    def show_settings_dialog(self):
        """Show Firebase settings dialog"""
        dialog = SettingsDialog(self.firebase, self)
        if dialog.exec():
            # Reload config and update APPS list
            self.config = self._load_config()
            self.APPS = self.config.get("apps", ["VEO", "CCT", "RAT", "G-LABS"])
            
            # Update app filter dropdown with new app list
            current_filter = self.app_filter_combo.currentText()
            self.app_filter_combo.clear()
            self.app_filter_combo.addItems(["All"] + self.APPS)
            
            # Restore selection if still valid, else default to "All"
            if current_filter in ["All"] + self.APPS:
                self.app_filter_combo.setCurrentText(current_filter)
            else:
                self.app_filter_combo.setCurrentText("All")
            
            # Reconnect Firebase with new settings
            self.connect_firebase()
            self.refresh_keys()
    
    def cleanup_expired_dialog(self):
        """Show cleanup options dialog"""
        summary = self.firebase.get_summary()
        
        msg = QMessageBox(self)
        msg.setWindowTitle("🧹 Cleanup Expired Keys")
        msg.setText(
            f"<b>Current Status:</b><br>"
            f"⏰ Expired: {summary['expired']}<br>"
            f"❌ Revoked: {summary['revoked']}<br><br>"
            f"<b>What would you like to do?</b>"
        )
        msg.setIcon(QMessageBox.Question)
        
        # Custom buttons
        mark_btn = msg.addButton("Mark Expired Only", QMessageBox.ActionRole)
        delete_expired_btn = msg.addButton("Delete Expired", QMessageBox.DestructiveRole)
        delete_all_btn = msg.addButton("Delete Expired + Revoked", QMessageBox.DestructiveRole)
        cancel_btn = msg.addButton("Cancel", QMessageBox.RejectRole)
        
        msg.exec()
        clicked = msg.clickedButton()
        
        if clicked == mark_btn:
            # Mark expired keys
            count = self.firebase.cleanup_expired_keys()
            QMessageBox.information(
                self, "✅ Cleanup Complete",
                f"Marked {count} expired keys.\n\nStatus changed from 'Active' to 'Expired'."
            )
            self.refresh_keys()
            
        elif clicked == delete_expired_btn:
            # Confirm delete expired
            reply = QMessageBox.warning(
                self, "⚠️ Confirm Delete Expired",
                f"This will PERMANENTLY DELETE all expired keys!\n\n"
                f"Estimated: {summary['expired']} keys\n\n"
                f"This action cannot be undone. Continue?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                count, backup_path = self.firebase.delete_expired_keys(include_revoked=False)
                if backup_path:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"Permanently deleted {count} expired keys.\n\n"
                        f"📁 Backup saved to:\n{backup_path}"
                    )
                else:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"No expired keys to delete (or backup failed)."
                    )
                self.refresh_keys()
                
        elif clicked == delete_all_btn:
            # Confirm delete expired + revoked
            total = summary['expired'] + summary['revoked']
            reply = QMessageBox.warning(
                self, "⚠️ Confirm Delete All",
                f"This will PERMANENTLY DELETE:\n\n"
                f"⏰ Expired keys: {summary['expired']}\n"
                f"❌ Revoked keys: {summary['revoked']}\n"
                f"───────────────\n"
                f"Total: {total} keys\n\n"
                f"A backup report will be saved before deletion.\n"
                f"Continue?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                count, backup_path = self.firebase.delete_expired_keys(include_revoked=True)
                if backup_path:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"Permanently deleted {count} keys (expired + revoked).\n\n"
                        f"📁 Backup saved to:\n{backup_path}"
                    )
                    # Offer to open backup folder
                    import subprocess
                    reply2 = QMessageBox.question(
                        self, "Open Backup Folder?",
                        "Would you like to open the backup folder?",
                        QMessageBox.Yes | QMessageBox.No
                    )
                    if reply2 == QMessageBox.Yes:
                        folder = str(Path(backup_path).parent)
                        subprocess.run(['explorer', folder])
                else:
                    QMessageBox.information(
                        self, "✅ Delete Complete",
                        f"No keys to delete (or backup failed)."
                    )
                self.refresh_keys()
    
    def show_requests_dialog(self):
        """Show pending requests dialog"""
        dialog = RequestsDialog(self.firebase, self)
        dialog.exec()
        self.update_requests_badge()
        self.refresh_keys()  # Refresh main table (new key may have been created)
    
    def update_requests_badge(self):
        """Update requests button with pending count"""
        summary = self.firebase.get_request_summary()
        pending = summary.get('pending', 0)
        if pending > 0:
            self.requests_btn.setText(f"📬 Requests ({pending})")
            self.requests_btn.setStyleSheet("background-color: #fab387; color: #1e1e2e;")
        else:
            self.requests_btn.setText("📬 Requests")
            self.requests_btn.setStyleSheet("")


# ============================================================
# REQUESTS DIALOG
# ============================================================

class RequestsDialog(QDialog):
    """Dialog for viewing and managing upgrade requests"""
    
    def __init__(self, firebase: FirebaseManager, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.requests_data = []
        self.setup_ui()
        self.refresh_requests()
    
    def setup_ui(self):
        self.setWindowTitle("📬 Upgrade Requests")
        self.setMinimumSize(1200, 650)
        
        layout = QVBoxLayout(self)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_requests)
        toolbar.addWidget(refresh_btn)
        
        # Status filter
        toolbar.addWidget(QLabel("  Filter:"))
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["📋 All", "⏳ Pending", "✅ Approved", "❌ Rejected", "🚫 Blocked"])
        self.filter_combo.setFixedWidth(150)
        self.filter_combo.currentIndexChanged.connect(self.refresh_requests)
        toolbar.addWidget(self.filter_combo)
        
        toolbar.addStretch()
        
        self.status_label = QLabel()
        toolbar.addWidget(self.status_label)
        
        layout.addLayout(toolbar)
        
        # Splitter
        splitter = QSplitter(Qt.Horizontal)
        
        # Requests table — 7 essential columns
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["Tên", "Machine ID", "Gói", "IP", "Lần gửi", "Ngày gửi", "Status"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 140)
        self.table.setColumnWidth(1, 100)
        self.table.setColumnWidth(2, 70)
        self.table.setColumnWidth(3, 120)
        self.table.setColumnWidth(4, 50)
        self.table.setColumnWidth(5, 130)
        self.table.setColumnWidth(6, 90)
        self.table.itemSelectionChanged.connect(self.on_request_selected)
        splitter.addWidget(self.table)
        
        # Details panel
        details_widget = QWidget()
        details_layout = QVBoxLayout(details_widget)
        
        # Request info
        info_group = QGroupBox("Thông tin yêu cầu")
        info_form = QFormLayout()
        
        self.detail_name = QLineEdit()
        self.detail_name.setReadOnly(True)
        info_form.addRow("Họ tên:", self.detail_name)
        
        self.detail_email = QLineEdit()
        self.detail_email.setReadOnly(True)
        info_form.addRow("Email:", self.detail_email)
        
        self.detail_machine = QLineEdit()
        self.detail_machine.setReadOnly(True)
        info_form.addRow("Machine ID:", self.detail_machine)
        
        self.detail_ip = QLineEdit()
        self.detail_ip.setReadOnly(True)
        info_form.addRow("🌐 Client IP:", self.detail_ip)
        
        self.detail_tier = QLineEdit()
        self.detail_tier.setReadOnly(True)
        info_form.addRow("Gói yêu cầu:", self.detail_tier)
        
        self.detail_app = QLineEdit()
        self.detail_app.setReadOnly(True)
        info_form.addRow("App:", self.detail_app)
        
        self.detail_send_count = QLineEdit()
        self.detail_send_count.setReadOnly(True)
        info_form.addRow("Số lần gửi:", self.detail_send_count)
        
        self.detail_st = QLineEdit()
        self.detail_st.setReadOnly(True)
        info_form.addRow("ST Token:", self.detail_st)
        
        self.detail_status = QLineEdit()
        self.detail_status.setReadOnly(True)
        info_form.addRow("Trạng thái:", self.detail_status)
        
        info_group.setLayout(info_form)
        details_layout.addWidget(info_group)
        
        # Approval section
        approval_group = QGroupBox("Phê duyệt")
        approval_form = QFormLayout()
        
        # Tier - VND Pricing Model
        self.tier_combo = QComboBox()
        self.tier_combo.addItems(["TRIAL", "ONE_MONTH", "THREE_MONTHS", "SIX_MONTHS", "ONE_YEAR", "LIFETIME"])
        self.tier_combo.setCurrentText("ONE_MONTH")
        self.tier_combo.currentTextChanged.connect(self.on_tier_changed)
        approval_form.addRow("Gói:", self.tier_combo)
        
        # Role
        self.role_combo = QComboBox()
        self.role_combo.addItems(["TRIAL (0)", "PREMIUM (1)", "TESTER (2)"])
        self.role_combo.setCurrentText("PREMIUM (1)")
        approval_form.addRow("Role:", self.role_combo)
        
        # App
        self.app_combo = QComboBox()
        apps = ["VEO", "CCT", "RAT", "G-LABS"]
        parent = self.parent()
        while parent:
            if hasattr(parent, 'APPS'):
                apps = parent.APPS
                break
            parent = parent.parent() if hasattr(parent, 'parent') else None
        self.app_combo.addItems(apps)
        self.app_combo.setCurrentText("VEO")
        approval_form.addRow("App:", self.app_combo)
        
        self.days_spin = QSpinBox()
        self.days_spin.setRange(7, 36500)
        self.days_spin.setValue(30)
        self.days_spin.setSuffix(" ngày")
        approval_form.addRow("Thời hạn:", self.days_spin)
        
        self.reject_reason = QLineEdit()
        self.reject_reason.setPlaceholderText("Lý do từ chối (nếu reject)")
        approval_form.addRow("Lý do từ chối:", self.reject_reason)
        
        approval_group.setLayout(approval_form)
        details_layout.addWidget(approval_group)
        
        # Action buttons
        action_layout = QHBoxLayout()
        
        approve_btn = QPushButton("✅ APPROVE")
        approve_btn.setStyleSheet("background-color: #a6e3a1; color: #1e1e2e; font-weight: bold;")
        approve_btn.clicked.connect(self.approve_request)
        action_layout.addWidget(approve_btn)
        
        reject_btn = QPushButton("❌ REJECT")
        reject_btn.setStyleSheet("background-color: #f38ba8; color: #1e1e2e; font-weight: bold;")
        reject_btn.clicked.connect(self.reject_request)
        action_layout.addWidget(reject_btn)
        
        details_layout.addLayout(action_layout)
        
        # Block button
        block_layout = QHBoxLayout()
        
        block_btn = QPushButton("🚫 BLOCK Machine")
        block_btn.setStyleSheet("background-color: #cba6f7; color: #1e1e2e; font-weight: bold;")
        block_btn.clicked.connect(self.block_request)
        block_layout.addWidget(block_btn)
        
        unblock_btn = QPushButton("🔓 Unblock")
        unblock_btn.setStyleSheet("background-color: #94e2d5; color: #1e1e2e; font-weight: bold;")
        unblock_btn.clicked.connect(self.unblock_request)
        block_layout.addWidget(unblock_btn)
        
        details_layout.addLayout(block_layout)
        details_layout.addStretch()
        
        splitter.addWidget(details_widget)
        splitter.setSizes([650, 500])
        
        layout.addWidget(splitter)
    
    def refresh_requests(self):
        """Refresh requests list with filter"""
        filter_idx = self.filter_combo.currentIndex() if hasattr(self, 'filter_combo') else 0
        
        if filter_idx == 0:  # All
            self.requests_data = self.firebase.get_all_requests()
        else:
            self.requests_data = self.firebase.get_all_requests()
            status_map = {1: "pending", 2: "approved", 3: "rejected", 4: "blocked"}
            filter_status = status_map.get(filter_idx)
            if filter_status == "blocked":
                self.requests_data = [r for r in self.requests_data if r.get('blocked')]
            else:
                self.requests_data = [r for r in self.requests_data 
                                     if r.get('status') == filter_status and not r.get('blocked')]
        
        self.table.setRowCount(len(self.requests_data))
        
        # Tier key → display name
        tier_display = {
            "1M": "1 Tháng", "3M": "3 Tháng", "6M": "6 Tháng",
            "1Y": "1 Năm", "LIFETIME": "Vĩnh viễn",
        }
        
        for i, req in enumerate(self.requests_data):
            name = req.get('client_name', '')
            mid = req.get('machine_id', '')[:12]
            tier = req.get('tier', '')
            tier_name = tier_display.get(tier, tier)
            app = req.get('app', 'VEO')
            email = req.get('email', '')
            send_count = str(req.get('send_count', 1))
            requested = req.get('requested_at', '')
            if hasattr(requested, 'strftime'):
                requested = requested.strftime('%Y-%m-%d %H:%M')
            elif isinstance(requested, str) and 'T' in requested:
                requested = requested[:16].replace('T', ' ')
            
            status = req.get('status', 'pending')
            if req.get('blocked'):
                status = "🚫 blocked"
            elif status == "pending":
                status = "⏳ pending"
            elif status == "approved":
                status = "✅ approved"
            elif status == "rejected":
                status = "❌ rejected"
            
            self.table.setItem(i, 0, QTableWidgetItem(name))
            self.table.setItem(i, 1, QTableWidgetItem(mid))
            self.table.setItem(i, 2, QTableWidgetItem(tier_name))
            self.table.setItem(i, 3, QTableWidgetItem(req.get('client_ip', '')))
            self.table.setItem(i, 4, QTableWidgetItem(send_count))
            self.table.setItem(i, 5, QTableWidgetItem(requested))
            self.table.setItem(i, 6, QTableWidgetItem(status))
        
        self.status_label.setText(f"Tổng: {len(self.requests_data)} yêu cầu")
    
    def on_request_selected(self):
        """Handle request selection — populate detail fields"""
        rows = self.table.selectedIndexes()
        if not rows:
            return
        
        row = rows[0].row()
        if row < len(self.requests_data):
            req = self.requests_data[row]
            
            self.detail_name.setText(req.get('client_name', ''))
            self.detail_email.setText(req.get('email', ''))
            self.detail_machine.setText(req.get('machine_id', ''))
            
            # IP with warning
            ip = req.get('client_ip', 'unknown')
            if ip == 'unknown':
                self.detail_ip.setText('⚠️ unknown')
                self.detail_ip.setStyleSheet('color: #f38ba8;')
            else:
                self.detail_ip.setText(ip)
                self.detail_ip.setStyleSheet('')
            
            self.detail_tier.setText(req.get('tier', ''))
            self.detail_app.setText(req.get('app', 'VEO'))
            self.detail_send_count.setText(str(req.get('send_count', 1)))
            self.detail_st.setText(req.get('st', ''))
            
            status = req.get('status', 'pending')
            if req.get('blocked'):
                status = "🚫 BLOCKED"
            self.detail_status.setText(status)
            
            # Auto-set approval tier from request
            tier_to_admin = {
                "1M": "ONE_MONTH", "3M": "THREE_MONTHS", "6M": "SIX_MONTHS",
                "1Y": "ONE_YEAR", "LIFETIME": "LIFETIME"
            }
            admin_tier = tier_to_admin.get(req.get('tier', ''), 'ONE_MONTH')
            idx = self.tier_combo.findText(admin_tier)
            if idx >= 0:
                self.tier_combo.setCurrentIndex(idx)
            
            # Set app from request
            app = req.get('app', 'VEO')
            app_idx = self.app_combo.findText(app)
            if app_idx >= 0:
                self.app_combo.setCurrentIndex(app_idx)
    
    def on_tier_changed(self, tier_text: str):
        """Handle tier change: auto-set duration and lock role for TRIAL tier"""
        TIER_DURATION = {
            "TRIAL": 7, "ONE_MONTH": 30, "THREE_MONTHS": 90,
            "SIX_MONTHS": 180, "ONE_YEAR": 365, "LIFETIME": 36500,
        }
        
        if tier_text in TIER_DURATION:
            self.days_spin.setValue(TIER_DURATION[tier_text])
        
        if tier_text in ["TRIAL", "LIFETIME"]:
            self.days_spin.setEnabled(False)
        else:
            self.days_spin.setEnabled(True)
        
        self.role_combo.clear()
        if tier_text == "TRIAL":
            self.role_combo.addItems(["TRIAL (0)", "TESTER (2)"])
            self.role_combo.setCurrentText("TRIAL (0)")
        else:
            self.role_combo.addItems(["PREMIUM (1)", "TESTER (2)"])
            self.role_combo.setCurrentText("PREMIUM (1)")
    
    def get_selected_request(self):
        """Get currently selected request"""
        rows = self.table.selectedIndexes()
        if not rows:
            return None
        
        row = rows[0].row()
        if row < len(self.requests_data):
            return self.requests_data[row]
        return None
    
    def approve_request(self):
        """Approve selected request"""
        req = self.get_selected_request()
        if not req:
            QMessageBox.warning(self, "Warning", "Vui lòng chọn một yêu cầu!")
            return
        
        tier_name = self.tier_combo.currentText()
        tier = LicenseTier.from_name(tier_name)
        days = self.days_spin.value()
        
        role_text = self.role_combo.currentText()
        role_code = int(role_text.split("(")[1].rstrip(")"))
        app = self.app_combo.currentText()
        
        reply = QMessageBox.question(
            self, "Xác nhận APPROVE",
            f"Duyệt yêu cầu của {req.get('client_name')}?\n\n"
            f"Machine ID: {req.get('machine_id', '')[:12]}...\n"
            f"Gói: {tier_name}\n"
            f"Role: {role_text}\n"
            f"App: {app}\n"
            f"Thời hạn: {days} ngày\n\n"
            f"License key sẽ được tự động tạo.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            success, result = self.firebase.approve_request(
                req.get('id'), tier, days, role=role_code, app_id=app
            )
            
            if success:
                QMessageBox.information(
                    self, "✅ Đã duyệt!",
                    f"License key đã được tạo:\n\n{result}\n\n"
                    f"Key đã được copy vào clipboard."
                )
                QApplication.clipboard().setText(result)
                self.accept()  # Close dialog → main table refreshes
            else:
                QMessageBox.critical(self, "Error", f"Lỗi: {result}")
    
    def reject_request(self):
        """Reject selected request"""
        req = self.get_selected_request()
        if not req:
            QMessageBox.warning(self, "Warning", "Vui lòng chọn một yêu cầu!")
            return
        
        reason = self.reject_reason.text().strip()
        if not reason:
            reason = "Yêu cầu không được duyệt"
        
        reply = QMessageBox.warning(
            self, "Xác nhận REJECT",
            f"Từ chối yêu cầu của {req.get('client_name')}?\n\n"
            f"Lý do: {reason}",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.reject_request(req.get('id'), reason):
                QMessageBox.information(self, "✅ Đã từ chối", "Yêu cầu đã bị từ chối.")
                self.accept()
            else:
                QMessageBox.critical(self, "Error", "Không thể từ chối yêu cầu!")
    
    def block_request(self):
        """Block machine from sending further requests"""
        req = self.get_selected_request()
        if not req:
            QMessageBox.warning(self, "Warning", "Vui lòng chọn một yêu cầu!")
            return
        
        reply = QMessageBox.warning(
            self, "🚫 Xác nhận BLOCK",
            f"Chặn vĩnh viễn machine {req.get('machine_id', '')[:12]}...?\n\n"
            f"Client: {req.get('client_name')}\n"
            f"Machine sẽ không thể gửi request nữa.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.firebase.block_machine(req.get('id')):
                QMessageBox.information(self, "🚫 Đã chặn", "Machine đã bị chặn vĩnh viễn.")
                self.accept()
            else:
                QMessageBox.critical(self, "Error", "Không thể chặn machine!")
    
    def unblock_request(self):
        """Unblock a blocked machine"""
        req = self.get_selected_request()
        if not req:
            QMessageBox.warning(self, "Warning", "Vui lòng chọn một yêu cầu!")
            return
        
        if not req.get('blocked'):
            QMessageBox.information(self, "Info", "Machine này chưa bị chặn.")
            return
        
        if self.firebase.unblock_machine(req.get('id')):
            QMessageBox.information(self, "🔓 Đã mở chặn", "Machine đã được mở chặn.")
            self.accept()
        else:
            QMessageBox.critical(self, "Error", "Không thể mở chặn!")


# ============================================================
# SETTINGS DIALOG
# ============================================================

class SettingsDialog(QDialog):
    """Dialog for managing Firebase credentials and backup settings"""
    
    CONFIG_FILE = Path.home() / ".veoauto" / "config.json"
    
    def __init__(self, firebase: FirebaseManager, parent=None):
        super().__init__(parent)
        self.firebase = firebase
        self.config = self.load_config()
        self.setup_ui()
    
    def load_config(self) -> dict:
        """Load config from file"""
        if self.CONFIG_FILE.exists():
            try:
                import json
                return json.loads(self.CONFIG_FILE.read_text(encoding='utf-8'))
            except:
                pass
        return {"primary_cred": "", "backup_cred": "", "auto_sync": False}
    
    def save_config(self):
        """Save config to file"""
        self.CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        import json
        self.CONFIG_FILE.write_text(json.dumps(self.config, indent=2), encoding='utf-8')
    
    def setup_ui(self):
        self.setWindowTitle("⚙️ Firebase Settings")
        self.setMinimumWidth(550)
        
        layout = QVBoxLayout(self)
        
        # === PRIMARY FIREBASE ===
        primary_group = QGroupBox("🔥 Firebase Primary")
        primary_layout = QFormLayout()
        
        self.primary_path = QLineEdit()
        self.primary_path.setText(self.config.get("primary_cred", ""))
        self.primary_path.setReadOnly(True)
        self.primary_path.setPlaceholderText("Chưa chọn credentials file...")
        
        primary_browse_btn = QPushButton("📂 Browse")
        primary_browse_btn.clicked.connect(lambda: self.browse_credentials("primary"))
        
        primary_row = QHBoxLayout()
        primary_row.addWidget(self.primary_path)
        primary_row.addWidget(primary_browse_btn)
        primary_layout.addRow("Credentials:", primary_row)
        
        self.primary_status = QLabel("⚪ Chưa kiểm tra")
        primary_layout.addRow("Status:", self.primary_status)
        
        test_primary_btn = QPushButton("🔗 Test Connection")
        test_primary_btn.clicked.connect(lambda: self.test_connection("primary"))
        primary_layout.addRow("", test_primary_btn)
        
        primary_group.setLayout(primary_layout)
        layout.addWidget(primary_group)
        
        # === BACKUP FIREBASE ===
        backup_group = QGroupBox("💾 Firebase Backup")
        backup_layout = QFormLayout()
        
        self.backup_path = QLineEdit()
        self.backup_path.setText(self.config.get("backup_cred", ""))
        self.backup_path.setReadOnly(True)
        self.backup_path.setPlaceholderText("(Optional) Backup Firebase credentials...")
        
        backup_browse_btn = QPushButton("📂 Browse")
        backup_browse_btn.clicked.connect(lambda: self.browse_credentials("backup"))
        
        backup_row = QHBoxLayout()
        backup_row.addWidget(self.backup_path)
        backup_row.addWidget(backup_browse_btn)
        backup_layout.addRow("Credentials:", backup_row)
        
        self.backup_status = QLabel("⚪ Chưa kiểm tra")
        backup_layout.addRow("Status:", self.backup_status)
        
        test_backup_btn = QPushButton("🔗 Test Connection")
        test_backup_btn.clicked.connect(lambda: self.test_connection("backup"))
        backup_layout.addRow("", test_backup_btn)
        
        backup_group.setLayout(backup_layout)
        layout.addWidget(backup_group)
        
        # === SYNC OPTIONS ===
        sync_group = QGroupBox("🔄 Sync Settings")
        sync_layout = QFormLayout()
        
        self.auto_sync_cb = QCheckBox("Tự động sync khi tạo/xóa key")
        self.auto_sync_cb.setChecked(self.config.get("auto_sync", False))
        sync_layout.addRow(self.auto_sync_cb)
        
        sync_now_btn = QPushButton("⚡ Sync Primary → Backup Now")
        sync_now_btn.clicked.connect(self.sync_databases)
        sync_layout.addRow(sync_now_btn)
        
        sync_group.setLayout(sync_layout)
        layout.addWidget(sync_group)
        
        # === API KEY MANAGEMENT (for REST Client) ===
        api_group = QGroupBox("🔑 Client API Keys (REST)")
        api_layout = QFormLayout()
        
        # Primary Web API Key
        self.primary_api_key = QLineEdit()
        self.primary_api_key.setPlaceholderText("AIzaSy...")
        self.primary_api_key.setEchoMode(QLineEdit.Password)
        self.primary_api_key.setText(self.config.get("primary_web_api_key", ""))
        api_layout.addRow("Primary Web API Key:", self.primary_api_key)
        
        # Backup Web API Key
        self.backup_api_key = QLineEdit()
        self.backup_api_key.setPlaceholderText("AIzaSy...")
        self.backup_api_key.setEchoMode(QLineEdit.Password)
        self.backup_api_key.setText(self.config.get("backup_web_api_key", ""))
        api_layout.addRow("Backup Web API Key:", self.backup_api_key)
        
        # Encryption mode
        self.static_mode_cb = QCheckBox("Static mode (multi-machine)")
        self.static_mode_cb.setChecked(self.config.get("use_static_key", False))
        self.static_mode_cb.setToolTip("Enable for distribution to multiple machines\nDisable for maximum security (hardware-bound)")
        api_layout.addRow(self.static_mode_cb)
        
        # Encryption status
        self.encryption_status = QLabel("🔐 AES-256 Encryption")
        api_layout.addRow("Status:", self.encryption_status)
        
        # Generate keys button
        gen_keys_btn = QPushButton("🔒 Generate Encrypted Keys")
        gen_keys_btn.clicked.connect(self.generate_encrypted_keys)
        api_layout.addRow(gen_keys_btn)
        
        api_group.setLayout(api_layout)
        layout.addWidget(api_group)
        
        # === APP MANAGER (Multi-app support) ===
        app_group = QGroupBox("🏠 App Manager")
        app_layout = QVBoxLayout()
        
        # Warning label
        warning_label = QLabel("⚠️ Xóa tên app không xóa license keys trong Firebase!")
        warning_label.setStyleSheet("color: #f9e2af; font-weight: bold;")
        app_layout.addWidget(warning_label)
        
        # App list
        from PySide6.QtWidgets import QListWidget
        self.app_list = QListWidget()
        self.app_list.addItems(self.config.get("apps", ["VEO", "CCT", "RAT", "G-LABS"]))
        self.app_list.setMaximumHeight(100)
        app_layout.addWidget(self.app_list)
        
        # Add/Remove buttons
        app_btn_layout = QHBoxLayout()
        
        add_app_btn = QPushButton("➕ Add App")
        add_app_btn.clicked.connect(self.add_app)
        app_btn_layout.addWidget(add_app_btn)
        
        edit_app_btn = QPushButton("✏️ Edit Selected")
        edit_app_btn.clicked.connect(self.edit_app)
        app_btn_layout.addWidget(edit_app_btn)
        
        remove_app_btn = QPushButton("➖ Remove Selected")
        remove_app_btn.clicked.connect(self.remove_app)
        app_btn_layout.addWidget(remove_app_btn)
        
        app_layout.addLayout(app_btn_layout)
        
        app_group.setLayout(app_layout)
        layout.addWidget(app_group)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.save_and_close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        # Update status on load
        self.update_statuses()
    
    def browse_credentials(self, which: str):
        """Browse for credentials JSON file"""
        from PySide6.QtWidgets import QFileDialog
        
        file_path, _ = QFileDialog.getOpenFileName(
            self, f"Select {which.title()} Firebase Credentials",
            str(Path.home()),
            "JSON Files (*.json)"
        )
        
        if file_path:
            if which == "primary":
                self.primary_path.setText(file_path)
                self.config["primary_cred"] = file_path
            else:
                self.backup_path.setText(file_path)
                self.config["backup_cred"] = file_path
            
            self.test_connection(which)
    
    def test_connection(self, which: str):
        """Test Firebase connection"""
        import firebase_admin
        from firebase_admin import credentials, firestore
        
        path = self.config.get(f"{which}_cred", "")
        status_label = self.primary_status if which == "primary" else self.backup_status
        
        if not path or not Path(path).exists():
            status_label.setText("❌ File không tồn tại")
            return
        
        try:
            # Create temporary app to test connection
            app_name = f"test_{which}_{id(self)}"
            cred = credentials.Certificate(path)
            test_app = firebase_admin.initialize_app(cred, name=app_name)
            
            # Try to access Firestore
            db = firestore.client(app=test_app)
            db.collection("_lic").limit(1).get()
            
            # Cleanup
            firebase_admin.delete_app(test_app)
            
            status_label.setText("✅ Kết nối thành công!")
            status_label.setStyleSheet("color: #a6e3a1;")
        except Exception as e:
            status_label.setText(f"❌ Lỗi: {str(e)[:50]}")
            status_label.setStyleSheet("color: #f38ba8;")
    
    def update_statuses(self):
        """Update connection statuses on load"""
        if self.config.get("primary_cred"):
            self.test_connection("primary")
        if self.config.get("backup_cred"):
            self.test_connection("backup")
    
    def generate_encrypted_keys(self):
        """Generate AES-256 encrypted API keys for client distribution"""
        import sys
        
        primary_key = self.primary_api_key.text().strip()
        backup_key = self.backup_api_key.text().strip()
        
        if not primary_key or not backup_key:
            QMessageBox.warning(self, "Warning", "Cần nhập cả 2 Web API Keys!")
            return
        
        if not primary_key.startswith("AIza") or not backup_key.startswith("AIza"):
            QMessageBox.warning(self, "Warning", "API Key phải bắt đầu bằng 'AIza'!")
            return
        
        # Save keys to config
        self.config["primary_web_api_key"] = primary_key
        self.config["backup_web_api_key"] = backup_key
        self.config["use_static_key"] = self.static_mode_cb.isChecked()
        
        # Generate encrypted keys
        try:
            client_dir = Path(__file__).parent.parent / "client"
            sys.path.insert(0, str(client_dir))
            
            from firebase_rest_client import _AES256Encryptor, _HardwareBinder, SecureFirebaseConfig
            
            use_static = self.static_mode_cb.isChecked()
            if use_static:
                key = SecureFirebaseConfig._STATIC_KEY
                mode = "static"
            else:
                key = _HardwareBinder.get_machine_key()
                mode = "hardware-bound"
            
            # Encrypt
            primary_encrypted = _AES256Encryptor.encrypt(primary_key, key)
            backup_encrypted = _AES256Encryptor.encrypt(backup_key, key)
            
            self.encryption_status.setText(f"✅ Keys encrypted ({mode})")
            
            QMessageBox.information(
                self, "Success",
                f"🔐 API Keys encrypted thành công!\n\n"
                f"Mode: {mode}\n"
                f"Primary: {len(primary_encrypted)} bytes\n"
                f"Backup: {len(backup_encrypted)} bytes\n\n"
                f"Keys đã được lưu vào _encrypted_api_keys.py"
            )
            
        except Exception as e:
            self.encryption_status.setText(f"❌ Error: {str(e)[:30]}")
            QMessageBox.critical(self, "Error", f"Không thể encrypt keys:\n{e}")
    
    def sync_databases(self):
        """Sync all keys from Primary to Backup"""
        primary_path = self.config.get("primary_cred", "")
        backup_path = self.config.get("backup_cred", "")
        
        if not primary_path or not backup_path:
            QMessageBox.warning(self, "Warning", "Cần cả Primary và Backup credentials!")
            return
        
        reply = QMessageBox.question(
            self, "Confirm Sync",
            "Sync toàn bộ licenses từ Primary → Backup?\n\n"
            "⚠️ Data trên Backup sẽ được ghi đè!",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        try:
            import firebase_admin
            from firebase_admin import credentials, firestore
            
            # Connect to both
            primary_app = firebase_admin.initialize_app(
                credentials.Certificate(primary_path), name=f"sync_primary_{id(self)}"
            )
            backup_app = firebase_admin.initialize_app(
                credentials.Certificate(backup_path), name=f"sync_backup_{id(self)}"
            )
            
            primary_db = firestore.client(app=primary_app)
            backup_db = firestore.client(app=backup_app)
            
            # Get all from primary
            docs = primary_db.collection("_lic").stream()
            count = 0
            
            for doc in docs:
                backup_db.collection("_lic").document(doc.id).set(doc.to_dict())
                count += 1
            
            # Cleanup
            firebase_admin.delete_app(primary_app)
            firebase_admin.delete_app(backup_app)
            
            QMessageBox.information(self, "✅ Sync Complete", f"Đã sync {count} licenses!")
            
        except Exception as e:
            QMessageBox.critical(self, "Sync Error", f"Lỗi sync: {e}")
    
    def add_app(self):
        """Add new app to list"""
        from PySide6.QtWidgets import QInputDialog
        name, ok = QInputDialog.getText(self, "Add App", "Tên app (viết hoa, không dấu):")
        if ok and name:
            name = name.upper().replace(" ", "_")
            if self.app_list.findItems(name, Qt.MatchExactly):
                QMessageBox.warning(self, "Trùng tên", f"App '{name}' đã tồn tại!")
                return
            self.app_list.addItem(name)
    
    def edit_app(self):
        """Edit selected app name with optional Firebase migration"""
        current = self.app_list.currentItem()
        if not current:
            QMessageBox.information(self, "Chọn app", "Vui lòng chọn một app để chỉnh sửa!")
            return
        
        old_name = current.text()
        
        # Custom dialog with migration checkbox
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QFormLayout, QLineEdit, QCheckBox, QDialogButtonBox
        
        dialog = QDialog(self)
        dialog.setWindowTitle(f"✏️ Edit App: {old_name}")
        dialog.setMinimumWidth(400)
        layout = QVBoxLayout(dialog)
        
        form = QFormLayout()
        name_input = QLineEdit(old_name)
        form.addRow("Tên mới:", name_input)
        
        migrate_cb = QCheckBox("🔄 Migrate Firebase keys (_app field)")
        migrate_cb.setChecked(True)
        migrate_cb.setToolTip("Cập nhật tất cả license keys trong Firebase với tên app mới")
        form.addRow(migrate_cb)
        
        layout.addLayout(form)
        
        # Warning label
        from PySide6.QtWidgets import QLabel
        warning = QLabel("⚠️ Migration sẽ cập nhật TẤT CẢ keys có _app='" + old_name + "'")
        warning.setStyleSheet("color: #f9e2af; font-size: 11px;")
        layout.addWidget(warning)
        
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() != QDialog.Accepted:
            return
        
        new_name = name_input.text().strip().upper().replace(" ", "_")
        
        if not new_name or new_name == old_name:
            return
        
        if self.app_list.findItems(new_name, Qt.MatchExactly):
            QMessageBox.warning(self, "Trùng tên", f"App '{new_name}' đã tồn tại!")
            return
        
        # Migrate Firebase if checked
        if migrate_cb.isChecked():
            count = self.migrate_app_in_firebase(old_name, new_name)
            if count >= 0:
                QMessageBox.information(
                    self, "✅ Migration hoàn tất",
                    f"Đã migrate {count} keys từ '{old_name}' → '{new_name}'"
                )
            else:
                return  # Migration failed
        
        # Update list
        current.setText(new_name)
    
    def migrate_app_in_firebase(self, old_name: str, new_name: str) -> int:
        """
        Migrate all license keys from old_name to new_name in Firebase.
        Returns count of migrated keys, or -1 on error.
        """
        if not self.firebase.connected:
            QMessageBox.warning(self, "Lỗi", "Chưa kết nối Firebase!")
            return -1
        
        try:
            # Query keys with old app name
            from google.cloud.firestore_v1.base_query import FieldFilter
            query = self.firebase.db.collection(self.firebase.COLLECTION).where(filter=FieldFilter("_app", "==", old_name))
            docs = list(query.stream())
            
            if not docs:
                QMessageBox.information(
                    self, "Thông báo", 
                    f"Không tìm thấy key nào với _app='{old_name}'"
                )
                return 0
            
            # Confirm
            reply = QMessageBox.question(
                self, "Xác nhận migrate",
                f"Tìm thấy {len(docs)} keys với _app='{old_name}'.\n\n"
                f"Bạn có muốn cập nhật tất cả sang _app='{new_name}'?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
            )
            
            if reply != QMessageBox.Yes:
                return -1
            
            # Batch update
            batch = self.firebase.db.batch()
            count = 0
            
            for doc in docs:
                doc_ref = self.firebase.db.collection(self.firebase.COLLECTION).document(doc.id)
                batch.update(doc_ref, {"_app": new_name})
                count += 1
                
                # Firestore limit: 500 per batch
                if count % 500 == 0:
                    batch.commit()
                    batch = self.firebase.db.batch()
            
            # Commit remaining
            if count % 500 != 0:
                batch.commit()
            
            return count
            
        except Exception as e:
            QMessageBox.critical(self, "Lỗi migration", f"Lỗi: {e}")
            return -1
    
    def remove_app(self):
        """Remove selected app from list"""
        current = self.app_list.currentItem()
        if not current:
            return
        
        name = current.text()
        reply = QMessageBox.warning(
            self, "⚠️ Xác nhận xóa", 
            f"Xóa app '{name}' chỉ xóa khỏi danh sách filter.\n"
            f"License keys với _app='{name}' vẫn còn trong Firebase!\n\n"
            f"Tiếp tục?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.app_list.takeItem(self.app_list.row(current))
    
    def save_and_close(self):
        """Save config and close"""
        self.config["auto_sync"] = self.auto_sync_cb.isChecked()
        
        # Save apps list
        apps = [self.app_list.item(i).text() for i in range(self.app_list.count())]
        self.config["apps"] = apps
        
        self.save_config()
        
        # Update main Firebase manager if primary changed
        if self.config.get("primary_cred"):
            os.environ['VEO_LICENSE_CONFIG'] = self.config["primary_cred"]
        
        self.accept()


# ============================================================
# MAIN
# ============================================================

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(DARK_STYLESHEET)
    
    window = LicenseManagerWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
