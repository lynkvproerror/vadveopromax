"""
License Admin Tool v2.1 - VND Pricing Model
Simplified flow: Machine ID required at key creation time

Usage:
    python license_admin.py create --machine-id 3946C15B --tier THREE_MONTHS --days 90
    python license_admin.py list
    python license_admin.py check XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX
    python license_admin.py revoke XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX
"""

import argparse
import json
import os
from pathlib import Path
from datetime import datetime
from typing import Optional

from license_keygen import LicenseKeyGenerator, LicenseTier

# Firebase Admin SDK
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False
    print("⚠️  firebase-admin not installed. Run: pip install firebase-admin")


class LicenseAdmin:
    """Admin tool for pre-bound license key management"""
    
    COLLECTION = "_lic"
    
    def __init__(self):
        self.db = None
        self._init_firebase()
    
    def _find_credentials(self) -> Optional[Path]:
        """Find Firebase credentials file"""
        search_paths = [
            os.environ.get('VEO_LICENSE_CONFIG'),
            os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'),
            Path(__file__).parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
            Path(__file__).parent.parent / "00_ADMIN" / "veoauto-f54b5-firebase-adminsdk-fbsvc-4d5a91e325.json",
            Path.home() / ".veoauto" / "firebase-credentials.json",
        ]
        
        for path in search_paths:
            if path and Path(path).exists():
                return Path(path)
        
        return None
    
    def _init_firebase(self):
        """Initialize Firebase connection"""
        if not FIREBASE_AVAILABLE:
            return
        
        cred_path = self._find_credentials()
        
        if not cred_path:
            print("❌ Firebase credentials not found!")
            print("   Place firebase-adminsdk.json in:")
            print("   - 00_ADMIN/ folder")
            print("   - ~/.veoauto/firebase-credentials.json")
            return
        
        try:
            if not firebase_admin._apps:
                cred = credentials.Certificate(str(cred_path))
                firebase_admin.initialize_app(cred)
            
            self.db = firestore.client()
            print(f"✅ Connected to Firebase")
        except Exception as e:
            print(f"❌ Firebase connection failed: {e}")
    
    def is_connected(self) -> bool:
        return self.db is not None
    
    # =====================
    # CREATE KEY (New flow)
    # =====================
    
    def create_key(
        self,
        machine_id: str,
        tier: LicenseTier,
        duration_days: int = 30,
        email: Optional[str] = None,
        note: Optional[str] = None
    ) -> Optional[str]:
        """
        Create a pre-bound license key.
        
        Args:
            machine_id: Client's machine ID (required!)
            tier: License tier
            duration_days: License duration
            email: Customer email (optional)
            note: Admin note (optional)
            
        Returns:
            Generated key string
        """
        if len(machine_id) < 4:
            print("❌ Machine ID must be at least 4 characters!")
            return None
        
        # Generate key
        key, metadata = LicenseKeyGenerator.generate(machine_id, tier, duration_days)
        
        print(f"🔑 Generated: {key}")
        print(f"   Machine ID: {machine_id}")
        print(f"   Tier: {tier.name}")
        print(f"   Expires: {metadata['expires'][:10]}")
        
        # Push to Firebase
        if self.is_connected():
            self._push_to_firebase(key, metadata, email, note)
            print(f"✅ Uploaded to Firebase")
        else:
            print(f"⚠️  Local only (no Firebase connection)")
        
        return key
    
    def _push_to_firebase(
        self, 
        key: str, 
        metadata: dict,
        email: Optional[str],
        note: Optional[str]
    ):
        """Push license record to Firebase Firestore"""
        doc_data = {
            "_t": metadata['tier'],
            "_st": "a",  # Active immediately (pre-bound!)
            "_cr": firestore.SERVER_TIMESTAMP,
            "_exp": datetime.fromisoformat(metadata['expires']),
            "_mid": metadata['machine_id'],  # Already bound!
            "_em": email,
            "_nt": note,
            "_dur": metadata['duration_days'],
        }
        
        self.db.collection(self.COLLECTION).document(key).set(doc_data)
    
    # =====================
    # LIST KEYS
    # =====================
    
    def list_keys(self, limit: int = 50) -> list:
        """List all license keys from Firebase"""
        if not self.is_connected():
            print("❌ Not connected to Firebase")
            return []
        
        docs = self.db.collection(self.COLLECTION).limit(limit).stream()
        
        keys = []
        print(f"\n{'KEY':<42} {'MID':<8} {'TIER':<6} {'STATUS':<8} {'EXPIRES':<12}")
        print("-" * 80)
        
        for doc in docs:
            data = doc.to_dict()
            key = doc.id
            mid = data.get('_mid', '????')[:8] if data.get('_mid') else '????'
            tier = data.get('_t', '?')
            status = "✅" if data.get('_st') == 'a' else "❌"
            
            exp = data.get('_exp')
            if exp:
                exp_str = exp.strftime('%Y-%m-%d') if hasattr(exp, 'strftime') else str(exp)[:10]
            else:
                exp_str = 'N/A'
            
            print(f"{key:<42} {mid:<8} {tier:<6} {status:<8} {exp_str:<12}")
            keys.append(key)
        
        print("-" * 80)
        print(f"Total: {len(keys)} keys")
        
        return keys
    
    # =====================
    # CHECK KEY
    # =====================
    
    def check_key(self, key: str) -> dict:
        """Check a key's status"""
        print(f"\n🔍 Key: {key}")
        
        # Firebase check
        if not self.is_connected():
            return {"valid": True, "source": "local_only"}
        
        doc = self.db.collection(self.COLLECTION).document(key).get()
        
        if not doc.exists:
            print(f"   ❌ Not found in Firebase")
            return {"valid": False, "error": "Key not in database"}
        
        data = doc.to_dict()
        status = "Active" if data.get('_st') == 'a' else "Revoked"
        exp = data.get('_exp')
        
        print(f"   Machine ID (full): {data.get('_mid', '?')[:16]}...")
        print(f"   Status: {status}")
        print(f"   Expires: {exp.strftime('%Y-%m-%d') if exp else 'N/A'}")
        print(f"   Email: {data.get('_em', 'N/A')}")
        
        return {"valid": True, "data": data}
    
    # =====================
    # REVOKE KEY
    # =====================
    
    def revoke_key(self, key: str, reason: str = "admin") -> bool:
        """Revoke a license key"""
        if not self.is_connected():
            print("❌ Not connected to Firebase")
            return False
        
        doc_ref = self.db.collection(self.COLLECTION).document(key)
        doc = doc_ref.get()
        
        if not doc.exists:
            print(f"❌ Key not found: {key}")
            return False
        
        doc_ref.update({
            "_st": "r",  # revoked
            "_rv_at": firestore.SERVER_TIMESTAMP,
            "_rv_reason": reason
        })
        
        print(f"✅ Revoked: {key}")
        print(f"   Reason: {reason}")
        return True


def main():
    parser = argparse.ArgumentParser(description="VEO License Admin v2.0")
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Create command
    create_parser = subparsers.add_parser("create", help="Create pre-bound license key")
    create_parser.add_argument("--machine-id", "-m", required=True, help="Client's machine ID (required)")
    create_parser.add_argument("--tier", "-t", 
                              choices=["TRIAL", "ONE_MONTH", "THREE_MONTHS", "SIX_MONTHS", "ONE_YEAR", "LIFETIME"], 
                              default="ONE_MONTH", help="License tier (VND pricing model)")
    create_parser.add_argument("--days", "-d", type=int, help="Duration in days (auto-set if not specified)")
    create_parser.add_argument("--email", "-e", type=str, help="Customer email")
    create_parser.add_argument("--note", "-n", type=str, help="Admin note")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List all keys")
    list_parser.add_argument("--limit", type=int, default=50, help="Max keys to list")
    
    # Check command
    check_parser = subparsers.add_parser("check", help="Check key status")
    check_parser.add_argument("key", help="Key to check")
    
    # Revoke command
    revoke_parser = subparsers.add_parser("revoke", help="Revoke a key")
    revoke_parser.add_argument("key", help="Key to revoke")
    revoke_parser.add_argument("--reason", "-r", default="admin", help="Revocation reason")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    admin = LicenseAdmin()
    
    if args.command == "create":
        tier = LicenseTier.from_name(args.tier)
        # Use tier's default duration if not specified
        days = args.days if args.days else tier.duration_days
        admin.create_key(
            machine_id=args.machine_id,
            tier=tier,
            duration_days=days,
            email=args.email,
            note=args.note
        )
    
    elif args.command == "list":
        admin.list_keys(limit=args.limit)
    
    elif args.command == "check":
        admin.check_key(args.key)
    
    elif args.command == "revoke":
        admin.revoke_key(args.key, args.reason)


if __name__ == "__main__":
    main()
